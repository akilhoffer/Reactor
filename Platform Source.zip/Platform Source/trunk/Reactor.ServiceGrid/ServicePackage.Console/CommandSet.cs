﻿namespace ServicePackage.Console
{
    // arguments: /p [PATH] /v
    public class CommandSet
    {
        public string PackCommandArgument { get; set; }

        public string DepositPackageArgument { get; set; }

        public bool Verbose { get; set; }

        public override string ToString()
        {
            return string.Format("PackCommandArgument: {0} | DepositPackageArgument: {1} | Verbose: {2}", PackCommandArgument, DepositPackageArgument, Verbose);
        }
    }
}
