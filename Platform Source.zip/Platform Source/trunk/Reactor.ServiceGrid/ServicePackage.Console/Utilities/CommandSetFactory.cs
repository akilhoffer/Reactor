﻿namespace ServicePackage.Console.Utilities
{
    public static class CommandSetFactory
    {
        public static CommandSet CreateCommandSet(string[] args)
        {
            return Args.Configuration.Configure<CommandSet>().CreateAndBind(args);
        }
    }
}
