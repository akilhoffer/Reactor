﻿using System.Collections.Generic;
using System.Activities;
using System.Configuration;

namespace ServicePackage.Console
{

    class Program
    {
        static void Main(string[] args)
        {
            var connectionString = (ConfigurationManager.ConnectionStrings["ReactorServices"] != null)
                                       ? ConfigurationManager.ConnectionStrings["ReactorServices"].ConnectionString
                                       : string.Empty;
            var workflowArguments = new Dictionary<string, object>
                                        {
                                            {"CommandLineArguments", args},
                                            {"ConnectionString", connectionString}
                                        };

            WorkflowInvoker.Invoke(new CommandWorkflow(), workflowArguments);
        }
    }
}
