﻿using System.Activities;
using Reactor.Environment;
using Reactor.ServiceGrid.Packages;
using Reactor.ServiceGrid.Repositories;
using ServicePackage.Console.Resources;

namespace ServicePackage.Console.Activities
{
    public class DeployPackage : CodeActivity
    {
        public InArgument<string> PackagePath { get; set; }
        public InArgument<string> ConnectionString { get; set; }

        #region Overrides of CodeActivity

        /// <summary>
        /// When implemented in a derived class, performs the execution of the activity.
        /// </summary>
        /// <param name="context">The execution context under which the activity executes.</param>
        protected override void Execute(CodeActivityContext context)
        {
            var packagePath = PackagePath.Get(context);
            System.Console.WriteLine();
            System.Console.WriteLine(ConsoleResources.DepositPackageCommandAttemptingToSavePackage, packagePath);

            var package = new ZipPackage(packagePath);
            var connectionData = new PlatformConnectionData {DatabaseConnectionString = ConnectionString.Get(context)};
            var repository = new SqlPackageRepository(connectionData);
            repository.AddPackage(package);

            System.Console.WriteLine();
            System.Console.WriteLine(ConsoleResources.DepositPackageCommandDepositedPackage);
        }

        #endregion
    }
}
