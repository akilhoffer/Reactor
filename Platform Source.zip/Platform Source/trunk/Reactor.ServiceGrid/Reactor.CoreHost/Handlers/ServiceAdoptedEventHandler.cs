﻿using System;
using MassTransit;
using Reactor.Messages.Events.Adoptions;

namespace Reactor.CoreHost.Handlers
{
    public class ServiceAdoptedEventHandler : Consumes<ServiceAdopted>.All
    {
        public void Consume(ServiceAdopted message)
        {
            // TODO: Fix this!
            throw new NotImplementedException();
            //AssertThatCurrentServiceIsAReactorCore();

            //var core = GetCurrentServiceAsReactorCore();
            //core.ResumeServiceTransfer(message, messageContext.WorkflowInstanceId);
        }
    }
}
