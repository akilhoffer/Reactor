﻿using System;
using MassTransit;
using Reactor.Environment;
using Reactor.Messages.Commands.Core;
using Reactor.ServiceGrid;
using log4net;

namespace Reactor.CoreHost.Handlers
{
    public class ShutdownServiceCommandHandler : Consumes<ShutdownService>.All
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(ShutdownServiceCommandHandler));

        public void Consume(ShutdownService message)
        {
            // TODO: Fix this!
            throw new NotImplementedException();

            //AssertThatCurrentServiceIsAReactorCore();

            //if (message.CoreName != Context.GridContext.CurrentReactorService.Identifier.Name) return;

            //var core = (IReactorCore)Context.GridContext.CurrentReactorService;

            //try
            //{
            //    // Instruct core to shutdown this service
            //    core.ShutdownService(new ServiceIdentifier { Name = message.ServiceName, Version = new Version(message.ServiceVersion) });
            //}
            //catch (InvalidOperationException e)
            //{
            //    _log.Error("ReactorCore threw an exception when ShutdownService was called.", e);
            //}
        }
    }
}
