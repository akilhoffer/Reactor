﻿using System;
using MassTransit;
using Reactor.Messages.Commands.Core;
using log4net;

namespace Reactor.CoreHost.Handlers
{
    public class TransferServiceCommandHandler : Consumes<TransferService>.All
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof (TransferServiceCommandHandler));

        public void Consume(TransferService message)
        {
            // TODO: Fix this!
            throw new NotImplementedException();

            //var core = GetCurrentServiceAsReactorCore();
            //if (message.FromCoreName != core.Identifier.Name)
            //{
            //    _log.WarnFormat("Cannot complete handling TransferService command because the donor Core in the command is not this Core instance. Donor Core name in command: {0}", message.FromCoreName);
            //    return;
            //}

            //try
            //{
            //    core.TransferService(message);
            //}
            //catch (Exception e)
            //{
            //    _log.Error("Core instance threw an exception while transfering service.", e);
            //}
        }
    }
}
