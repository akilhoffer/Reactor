﻿namespace Reactor.Messages.Commands
{
    /// <summary>
    /// Command to shut down the matching service.
    /// </summary>
    public class ShutdownCommand
    {
        /// <summary>
        /// Gets or sets the name of the service that is being commanded to shut down.
        /// </summary>
        /// <value>The name of the service.</value>
        public string ServiceName { get; set; }

        /// <summary>
        /// Gets or sets the unique identifier of the service being commanded to shut down.
        /// </summary>
        /// <value>The service id.</value>
        public int ServiceId { get; set; }
    }
}
