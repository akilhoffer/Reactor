﻿namespace Reactor.Messages.Commands
{
    public interface ICommand
    {
    }
}
