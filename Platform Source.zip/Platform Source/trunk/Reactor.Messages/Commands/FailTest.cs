﻿namespace Reactor.Messages.Commands
{
    public class FailTest
    {
        public bool Fail { get; set; }
    }
}
