﻿namespace Reactor.Messages.Commands.Core
{
    public class UpgradeService : ICommand
    {
        public string CoreName { get; set; }

        public string ServiceName { get; set; }

        public string FromVersion { get; set; }

        public string ToVersion { get; set; }
    }
}
