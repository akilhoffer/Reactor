﻿using System;

namespace Reactor.Messages.Commands.Core
{
    public class AdoptService : ICommand
    {
        /// <summary>
        /// Gets or sets the name of the service to adopt.
        /// </summary>
        /// <value>The service id.</value>
        public string ServiceName { get; set; }

        /// <summary>
        /// Gets or sets the version of the service to adopt.
        /// </summary>
        /// <value>The service version.</value>
        public string ServiceVersion { get; set; }

        /// <summary>
        /// Gets or sets the name of the core that is to adopt the service.
        /// </summary>
        /// <value>The core name.</value>
        public string CoreName { get; set; }

        /// <summary>
        /// Gets or sets the startup arguments.
        /// </summary>
        /// <value>The startup arguments.</value>
        public string StartupArguments { get; set; }
    }
}
