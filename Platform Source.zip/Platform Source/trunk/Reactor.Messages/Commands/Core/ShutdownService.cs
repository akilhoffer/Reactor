﻿namespace Reactor.Messages.Commands.Core
{
    public class ShutdownService : ICommand
    {
        /// <summary>
        /// Gets or sets the name of the Core being instructed to shutdown the specified service.
        /// </summary>
        /// <value>The name of the core.</value>
        public string CoreName { get; set; }

        /// <summary>
        /// Gets or sets the name of the service to shutdown.
        /// </summary>
        /// <value>The name of the service.</value>
        public string ServiceName { get; set; }

        /// <summary>
        /// Gets or sets the version of the service to shutdown.
        /// </summary>
        /// <value>The version.</value>
        public string ServiceVersion { get; set; }
    }
}
