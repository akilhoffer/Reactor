﻿namespace Reactor.Messages.Commands.Core
{
    public class RestartService : ICommand
    {
        /// <summary>
        /// Gets or sets the name of the Core that is to perform the restart.
        /// </summary>
        /// <value>The name of the core.</value>
        public string CoreName { get; set; }

        /// <summary>
        /// Gets or sets the name of the service that is to be restarted.
        /// </summary>
        /// <value>The name of the service.</value>
        public string ServiceName { get; set; }

        /// <summary>
        /// Gets or sets the version of the service that is to be restarted.
        /// </summary>
        /// <value>The service version.</value>
        public string ServiceVersion { get; set; }
    }
}
