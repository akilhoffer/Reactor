﻿using System;
using MassTransit;

namespace Reactor.Messages.Requests
{
    /// <summary>
    /// Message class used as a test request. The two numbers should be added on the receiving end and the result returned to the sender.
    /// </summary>
    public class SimpleMathRequest : CorrelatedBy<Guid>
    {
        public int FirstNumber { get; set; }

        public int SecondNumber { get; set; }

        public Guid CorrelationId { get; set; }
    }
}
