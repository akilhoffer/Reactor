﻿namespace Reactor.Messages.Requests.Diagnostics
{
    public class EndpointDiagnosticsRequest
    {
        
    }
}
