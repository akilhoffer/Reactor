﻿namespace Reactor.Messages.Requests
{
    /// <summary>
    /// Message used to request a health report from a Reactor Service or Reactor Core
    /// </summary>
    public class RequestHealthReport
    {
        /// <summary>
        /// Gets or sets the name of the input queue the request originator is expecting an answer on.
        /// </summary>
        /// <value>The originator.</value>
        public string Originator { get; set; }
    }
}
