﻿namespace Reactor.Messages.Requests
{
    /// <summary>
    /// Message intended to signal all running Reactor Cores to collect and send a new <see cref="CoreHealthReport"/>.
    /// </summary>
    public class RequestCoreHealthReports {}

    /// <summary>
    /// Message intended to signal a single Reactor Core to collect and send a new <see cref="CoreHealthReport"/>.
    /// </summary>
    public class RequestSpecificCoreHealthReport {}
}
