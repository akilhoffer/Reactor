﻿using System;
using MassTransit;

namespace Reactor.Messages.Replies
{
    /// <summary>
    /// Message class used as a test reply. The Sum property is the sum of two numbers in the request message.
    /// </summary>
    public class SimpleMathReply : CorrelatedBy<Guid>
    {
        public int FirstNumber { get; set; }

        public int SecondNumber { get; set; }

        public int Sum { get; set; }

        public Guid CorrelationId { get; set; }
    }
}
