﻿namespace Reactor.Messages.Replies.Diagnostics
{
    public class EndpointDiagnosticsResponse
    {
        public string SubscriberName { get; set; }

        public DestinationToMessageTypesMap[] DestinationToMessageTypesMaps { get; set; }

        public class DestinationToMessageTypesMap
        {
            public string[] MessageTypeNames { get; set; }
            public string DestinationName { get; set; }
        }
    }
}
