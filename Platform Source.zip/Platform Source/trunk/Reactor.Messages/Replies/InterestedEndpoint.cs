﻿using System.Globalization;

namespace Reactor.Messages.Replies
{
    /// <summary>
    /// Reply message intended to notify all listening endpoints of message types the sending endpoint is interested in 
    /// and what destination they expect the messages to be sent.
    /// </summary>
    public class InterestedEndpoint
    {
        /// <summary>
        /// Gets or sets the destination mappings.
        /// </summary>
        /// <value>The destination mappings.</value>
        public DestinationMapping[] DestinationMappings { get; set; }

        /// <summary>
        /// Gets or sets the name of the endpoint.
        /// </summary>
        /// <value>The name of the endpoint.</value>
        public string EndpointName { get; set; }

        public class DestinationMapping
        {
            public string DestinationName { get; set; }

            public string[] MessageTypeNames { get; set; }

            public bool DestinationIsQueue
            {
                get
                {
                    // Assume topic if DestinationName is blank or null
                    if (string.IsNullOrEmpty(DestinationName)) return false;

                    // Check for queue prefix. If not found, assume topic.
                    return DestinationName.StartsWith("queue://", true, CultureInfo.CurrentCulture);
                }
            }
        }
    }
}
