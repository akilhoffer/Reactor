﻿namespace Reactor.Messages
{
    /// <summary>
    /// Interface to signify an advisory message
    /// </summary>
    public interface IAdvisoryMessage
    {
        /// <summary>
        /// Gets or sets the subject of the event.
        /// </summary>
        /// <value>The subject.</value>
        string Subject { get; set; }

        /// <summary>
        /// Gets or sets a detailed description of the event.
        /// </summary>
        /// <value>The description.</value>
        string Description { get; set; }
    }
}
