﻿namespace Reactor.Messages.Events.Endpoint
{
    public class EndpointOnline
    {
        /// <summary>
        /// Gets or sets the name of the subscriber. Other endpoints can use this information 
        /// to lookup subscription information for endpoints coming online.
        /// </summary>
        /// <value>The name of the subscriber.</value>
        public string SubscriberName { get; set; }
    }
}
