﻿namespace Reactor.Messages.Events.Endpoint
{
    /// <summary>
    /// Event message sent whenever an endpoint makes changes to it's subscriptions.
    /// </summary>
    public class EndpointSubscriptionChanged
    {
        /// <summary>
        /// Gets or sets the name of the endpoint that made the change.
        /// </summary>
        /// <value>The name of the endpoint.</value>
        public string EndpointName { get; set; }
    }
}
