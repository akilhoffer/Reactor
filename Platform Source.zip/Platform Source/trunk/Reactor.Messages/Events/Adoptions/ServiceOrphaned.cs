﻿namespace Reactor.Messages.Events.Adoptions
{
    public class ServiceOrphaned : IAdvisoryMessage
    {
        /// <summary>
        /// Gets or sets the name of the service that was adopted.
        /// </summary>
        /// <value>The service name.</value>
        public string ServiceName { get; set; }

        /// <summary>
        /// Gets or sets the version of the service that was adopted.
        /// </summary>
        /// <value>The version.</value>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the name of the core that adopted the service.
        /// </summary>
        /// <value>The core name.</value>
        public string CoreName { get; set; }

        #region Implementation of IAdvisoryMessage

        /// <summary>
        /// Gets or sets the subject of the event.
        /// </summary>
        /// <value>The subject.</value>
        public string Subject { get; set; }

        /// <summary>
        /// Gets or sets a detailed description of the event.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        #endregion
    }
}
