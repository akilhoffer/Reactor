﻿namespace Reactor.Messages.Events.Failures
{
    public class MonitorFailed
    {
        public string CoreName { get; set; }
    }
}
