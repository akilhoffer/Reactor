﻿namespace Reactor.Messages.Events.Failures.Adoption
{
    public class AdoptionFailed : IAdvisoryMessage
    {
        /// <summary>
        /// Gets or sets the name of the service that failed to be adopted.
        /// </summary>
        /// <value>The service name.</value>
        public string ServiceName { get; set; }

        public string Version { get; set; }

        public string CoreName { get; set; }

        #region Implementation of IAdvisoryMessage

        /// <summary>
        /// Gets or sets the subject of the event.
        /// </summary>
        /// <value>The subject.</value>
        public string Subject { get; set; }

        /// <summary>
        /// Gets or sets a detailed description of the event.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        #endregion
    }
}
