﻿namespace Reactor.Messages.Events.Failures
{
    public class RestartServiceFailed : IAdvisoryMessage
    {
        #region Implementation of IAdvisoryMessage

        /// <summary>
        /// Gets or sets the subject of the event.
        /// </summary>
        /// <value>The subject.</value>
        public string Subject { get; set; }

        /// <summary>
        /// Gets or sets a detailed description of the event.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        #endregion
    }
}
