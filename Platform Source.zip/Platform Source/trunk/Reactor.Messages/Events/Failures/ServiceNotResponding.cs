﻿using System;

namespace Reactor.Messages.Events.Failures
{
    /// <summary>
    /// This message is sent by a Reactor Core whenever one of it's managed Reactor Services 
    /// fails to check in within the configured timespan.
    /// </summary>
    public class ServiceNotResponding
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>The version.</value>
        public Version Version { get; set; }

        /// <summary>
        /// Gets or sets the instance identifier.
        /// </summary>
        /// <value>The instance identifier.</value>
        public Guid InstanceIdentifier { get; set; }
    }
}
