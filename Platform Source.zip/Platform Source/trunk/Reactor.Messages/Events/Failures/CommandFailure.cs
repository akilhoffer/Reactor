﻿using Reactor.Messages.Commands;

namespace Reactor.Messages.Events.Failures
{
    public class CommandFailure<T>  where T : ICommand
    {
        /// <summary>
        /// Gets or sets the failed command.
        /// </summary>
        /// <value>The failed command.</value>
        public T FailedCommand { get; set;}
    }
}
