﻿namespace Reactor.Messages.Events.Health
{
    /// <summary>
    /// Test message used to embody a simple service pulse from test services.
    /// </summary>
    public class Pulse
    {
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; }
    }
}
