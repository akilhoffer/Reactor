﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using MassTransit;
using Reactor.Connections.Default;
using Reactor.Container.Unity;
using Reactor.Customization;

namespace Reactor.Client.Web
{
    public class Global : HttpApplication
    {
        public static IServiceBus ServiceBus { get; set; }

        protected void Application_Start(object sender, EventArgs e)
        {
            Application.Lock();

            try
            {
                // TODO: Fix this!
                //SetupServiceLocator();
                //SetupConnectionData();

                //var initManager = new InitializationCustomizationManager();
                //initManager.RunAll();

                //ServiceBus = Environment.Context.ServiceBus;
            }
            finally
            {
                Application.UnLock();
            }
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {
            Application.Lock();

            try
            {
                ServiceBus.Shutdown();
            }
            finally
            {
                Application.UnLock();
            }
        }

        private static void SetupServiceLocator()
        {
            var containerCustomizer = new ContainerCustomizer();
            containerCustomizer.InitializeReactor();
        }

        private void SetupConnectionData()
        {
            var connectionsCustomizer = new ConnectionDataCustomizer();
            connectionsCustomizer.InitializeReactor();
        }
    }
}