﻿using System;
using MassTransit;
using System.ServiceModel;
using System.ServiceModel.Activation;
using Reactor.Client.Web.Models.Shared;
using Reactor.Messages.Commands.Core;

namespace Reactor.Client.Web.Services
{
    [ServiceContract(Namespace = "Reactor.Services")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class CommandService
    {
        [OperationContract]
        public void SendAdoptCommand(AdoptServiceCommand adoptServiceCommand)
        {
            AssertThatServiceBusIsReady();

            var cmd = new AdoptService 
            {
                CoreName = adoptServiceCommand.CoreName, 
                ServiceName = adoptServiceCommand.ServiceName,
                ServiceVersion = adoptServiceCommand.ServiceVersion
            };
            Global.ServiceBus.Publish(cmd);
        }

        [OperationContract]
        public void SendOrphanCommand(OrphanServiceCommand orphanServiceCommand)
        {
            AssertThatServiceBusIsReady();

            var cmd = new OrphanService
            {
                CoreName = orphanServiceCommand.CoreName,
                ServiceName = orphanServiceCommand.ServiceName,
                ServiceVersion = orphanServiceCommand.ServiceVersion
            };
            Global.ServiceBus.Publish(cmd);
        }

        [OperationContract]
        public void SendTransferCommand(TransferServiceCommand transferServiceCommand)
        {
            AssertThatServiceBusIsReady();

            var cmd = new TransferService
            {
                FromCoreName = transferServiceCommand.FromCoreName,
                ToCoreName = transferServiceCommand.ToCoreName,
                ServiceName = transferServiceCommand.ServiceName,
                ServiceVersion = transferServiceCommand.ServiceVersion
            };
            Global.ServiceBus.Publish(cmd);
        }

        [OperationContract]
        public void SendUpgradeServiceCommand(UpgradeServiceCommand upgradeServiceCommand)
        {
            AssertThatServiceBusIsReady();

            var cmd = new UpgradeService
            {
                CoreName = upgradeServiceCommand.CoreName,
                FromVersion = upgradeServiceCommand.FromVersion,
                ToVersion = upgradeServiceCommand.ToVersion,
                ServiceName = upgradeServiceCommand.ServiceName
            };
            Global.ServiceBus.Publish(cmd);
        }

        private static void AssertThatServiceBusIsReady()
        {
            if(Global.ServiceBus == null)
                throw new InvalidOperationException("No IServiceBus instance found.");

            // TODO: Fix this!
            //if(!Global.ServiceBus.IsRunning)
            //    throw new InvalidOperationException("IServiceBus instance located is not running.");
        }
    }
}
