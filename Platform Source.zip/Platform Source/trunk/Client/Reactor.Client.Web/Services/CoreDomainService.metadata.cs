﻿
namespace Reactor.Client.Web.Data
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.ServiceModel.DomainServices.Hosting;
    using System.ServiceModel.DomainServices.Server;


    // The MetadataTypeAttribute identifies CoreMetadata as the class
    // that carries additional metadata for the Core class.
    [MetadataTypeAttribute(typeof(Core.CoreMetadata))]
    public partial class Core
    {

        // This class allows you to attach custom attributes to properties
        // of the Core class.
        //
        // For example, the following marks the Xyz property as a
        // required property and specifies the format for valid values:
        //    [Required]
        //    [RegularExpression("[A-Z][A-Za-z0-9]*")]
        //    [StringLength(32)]
        //    public string Xyz { get; set; }
        internal sealed class CoreMetadata
        {

            // Metadata classes are not meant to be instantiated.
            private CoreMetadata()
            {
            }

            public Nullable<DateTime> LastSeen { get; set; }

            public string Name { get; set; }

            public string Version { get; set; }
        }
    }
}
