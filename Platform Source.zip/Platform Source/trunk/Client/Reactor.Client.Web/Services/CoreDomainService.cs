﻿using System.Linq;
using System.ServiceModel.DomainServices.EntityFramework;
using System.ServiceModel.DomainServices.Hosting;
using System.ServiceModel.DomainServices.Server;
using Reactor.Client.Web.Data;

namespace Reactor.Client.Web.Services
{
    // Implements application logic using the ReactorServicesEntities context.
    // TODO: Wire up authentication (Windows/ASP.NET Forms) and uncomment the following to disable anonymous access
    // Also consider adding roles to restrict access as appropriate.
    // [RequiresAuthentication]
    [EnableClientAccess]
    public class CoreDomainService : LinqToEntitiesDomainService<ReactorServicesEntities>
    {
        [Query(IsDefault = true)]
        public IQueryable<ReactorCore> GetCores()
        {
            return ObjectContext.ReactorCores;
        }

        [Query]
        public IQueryable<Service> GetServicesByCore(string coreName)
        {
            return ObjectContext.Services.Where(s => s.CoreName == coreName);
        }

        [Query]
        public IQueryable<ConfigurationItem> GetConfigurationItem(string key)
        {
            return (from i in ObjectContext.ConfigurationItems
                    where i.ConfigKey == key
                    select i);
        }

        [Query]
        public IQueryable<ServicePackageInfo> GetAllServicePackageInfo()
        {
            return ObjectContext.ServicePackageInfoes;
        }
    }
}
