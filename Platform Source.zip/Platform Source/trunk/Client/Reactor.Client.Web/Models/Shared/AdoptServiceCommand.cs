﻿namespace Reactor.Client.Web.Models.Shared
{
    public class AdoptServiceCommand
    {
        public string CoreName { get; set; }

        public string ServiceName { get; set; }

        public string ServiceVersion { get; set; }
    }
}