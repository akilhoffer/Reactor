﻿namespace Reactor.Client.Web.Models.Shared
{
    /// <summary>
    /// A command intended to instruct Reactor Cores to orphan the specified service.
    /// </summary>
    public class OrphanServiceCommand
    {
        /// <summary>
        /// Gets or sets the name of the core that is to receive this command.
        /// </summary>
        /// <value>The name of the core.</value>
        public string CoreName { get; set; }

        /// <summary>
        /// Gets or sets the name of the service that is to be orphaned.
        /// </summary>
        /// <value>The name of the service.</value>
        public string ServiceName { get; set; }

        /// <summary>
        /// Gets or sets the version of the service that is to be orphaned.
        /// </summary>
        /// <value>The service version.</value>
        public string ServiceVersion { get; set; }
    }
}