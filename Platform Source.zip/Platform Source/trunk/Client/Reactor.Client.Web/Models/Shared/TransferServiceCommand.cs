﻿namespace Reactor.Client.Web.Models.Shared
{
    public class TransferServiceCommand
    {
        /// <summary>
        /// Gets or sets the name of the service to adopt.
        /// </summary>
        /// <value>The service id.</value>
        public string ServiceName { get; set; }

        /// <summary>
        /// Gets or sets the version of the service to adopt.
        /// </summary>
        /// <value>The service version.</value>
        public string ServiceVersion { get; set; }

        /// <summary>
        /// Gets or sets the name of the core from which the target service is to be transfered.
        /// </summary>
        /// <value>The core name.</value>
        public string FromCoreName { get; set; }

        /// <summary>
        /// Gets or sets the name of to Core to which the target service is to be transfered.
        /// </summary>
        /// <value>The name of to core.</value>
        public string ToCoreName { get; set; }
    }
}