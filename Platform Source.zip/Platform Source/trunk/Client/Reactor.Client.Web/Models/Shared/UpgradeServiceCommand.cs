﻿namespace Reactor.Client.Web.Models.Shared
{
    public class UpgradeServiceCommand
    {
        public string CoreName { get; set; }

        public string ServiceName { get; set; }

        public string FromVersion { get; set; }

        public string ToVersion { get; set; }
    }
}