﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace Reactor.Client
{
    public static class FrameworkElementExtensions
    {
        public static void RegisterForNotification(this FrameworkElement frameworkElement, string propertyName, FrameworkElement element, PropertyChangedCallback callback)
        {
            //Bind to a depedency property
            Binding b = new Binding(propertyName) { Source = element };
            var prop = DependencyProperty.RegisterAttached(
                "ListenAttached" + propertyName,
                typeof(object),
                typeof(UserControl),
                new PropertyMetadata(callback));

            element.SetBinding(prop, b);
        }
    }
}
