﻿using System.ComponentModel.DataAnnotations;
using System.ServiceModel.DomainServices.Client;

namespace Reactor.Client.Models
{
    public class OrphanServiceForm : Entity
    {
        private string _serviceDisplay;
        private string _coreName;
        private bool _isBusy;

        [Editable(false)]
        [Display(Name = "Service:", Description = "The Service instance that is to be orphaned by the selected Core.")]
        public string ServiceDisplay
        {
            get { return _serviceDisplay; }
            set
            {
                if (value == _serviceDisplay) return;

                _serviceDisplay = value;
                RaisePropertyChanged("ServiceDisplay");
            }
        }

        [Editable(false)]
        [Display(Name = "Core:", Description = "The Core that currently manages the Service below. This Core will be issued a command to orphan the Service once the intention to orphan is confirmed.")]
        public string CoreName
        {
            get { return _coreName; }
            set
            {
                if (value == _coreName) return;

                _coreName = value;
                RaisePropertyChanged("CoreName");
            }
        }

        [Display(AutoGenerateField = false)]
        public bool IsBusy
        {
            get { return _isBusy; }
            set
            {
                if (value == _isBusy) return;

                _isBusy = value;
                RaisePropertyChanged("IsBusy");
            }
        }
    }
}
