﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ServiceModel.DomainServices.Client;
using Reactor.Client.ViewModel;

namespace Reactor.Client.Models
{
    public class AdoptionModel : Entity
    {
        private ServicePackageViewModel _selectedServicePackage;

        [Editable(false)]
        [Display(Name = "Recipient Core:", Description = "The Core instance that is to be instructed to adopt the specified Service.")]
        public string CoreName { get; set; }

        public IEnumerable<ServicePackageViewModel> ServicePackages { get; set; }

        [Display(Name = "Service:", Description = "The Service to be adopted by the recipient Core.")]
        public ServicePackageViewModel SelectedServicePackage
        {
            get { return _selectedServicePackage; }
            set
            {
                if (value == _selectedServicePackage) return;

                _selectedServicePackage = value;
                RaisePropertyChanged("SelectedServicePackage");
            }
        }
    }
}
