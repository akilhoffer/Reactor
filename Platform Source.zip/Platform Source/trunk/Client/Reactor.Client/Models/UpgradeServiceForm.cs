﻿using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.ServiceModel.DomainServices.Client;

namespace Reactor.Client.Models
{
    public class UpgradeServiceForm : Entity
    {
        #region Fields

        private string _coreName;
        private string _serviceName;
        private string _fromVersion;
        private string _toVersion;
        private bool _isBusy;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="UpgradeServiceForm"/> class.
        /// </summary>
        public UpgradeServiceForm()
        {
            PossibleUpgradeVersions = new ObservableCollection<string>();
        }

        [Editable(false)]
        [Display(Name = "Core:", Description = "The Reactor Core managing the target service. This Core will perform the upgrade.")]
        public string CoreName
        {
            get { return _coreName; }
            set
            {
                if (value == _coreName) return;

                _coreName = value;
                RaisePropertyChanged("CoreName");
            }
        }

        [Editable(false)]
        [Display(Name = "Target service:", Description = "The service being upgraded.")]
        public string ServiceName
        {
            get { return _serviceName; }
            set
            {
                if (value == _serviceName) return;

                _serviceName = value;
                RaisePropertyChanged("ServiceName");
            }
        }

        [Editable(false)]
        [Display(Name = "From version:", Description = "The current version of the target service.")]
        public string FromVersion
        {
            get { return _fromVersion; }
            set
            {
                if (value == _fromVersion) return;

                _fromVersion = value;
                RaisePropertyChanged("FromVersion");
            }
        }

        public ObservableCollection<string> PossibleUpgradeVersions { get; private set; }

        [Display(Name = "To version:", Description = "The version to upgrade the target service to.")]
        public string ToVersion
        {
            get { return _toVersion; }
            set
            {
                if (value == _toVersion) return;

                _toVersion = value;

                RaisePropertyChanged("ToVersion");
            }
        }

        [Display(AutoGenerateField = false)]
        public bool IsBusy
        {
            get { return _isBusy; }
            set
            {
                if (value == _isBusy) return;

                _isBusy = value;
                RaisePropertyChanged("IsBusy");
            }
        }
    }
}
