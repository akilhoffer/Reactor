﻿using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.ServiceModel.DomainServices.Client;

namespace Reactor.Client.Models
{
    public class TransferServiceForm : Entity
    {
        #region Fields

        private string _fromCoreName;
        private string _toCoreName;
        private string _serviceName;
        private string _serviceVersion;
        private bool _isBusy;

        #endregion

        public TransferServiceForm()
        {
            AvailableCores = new ObservableCollection<string>();
        }

        [Editable(false)]
        [Display(Name = "Service:", Description = "The Reactor Service to be transfered.")]
        public string ServiceName
        {
            get { return _serviceName; }
            set
            {
                if (value == _serviceName) return;

                _serviceName = value;
                RaisePropertyChanged("ServiceName");
            }
        }

        [Editable(false)]
        [Display(Name = "Version:", Description = "The version of the Reactor Service to transfer.")]
        public string ServiceVersion
        {
            get { return _serviceVersion; }
            set
            {
                if (value == _serviceVersion) return;

                _serviceVersion = value;
                RaisePropertyChanged("ServiceVersion");
            }
        }

        [Editable(false)]
        [Display(Name = "Donor Core:", Description = "The Reactor Core that is to orphan the target Reactor Service.")]
        public string FromCoreName
        {
            get { return _fromCoreName; }
            set
            {
                if (value == _fromCoreName) return;

                _fromCoreName = value;
                RaisePropertyChanged("FromCoreName");
            }
        }

        [Display(Name = "Recipient Core:", Description = "The Reactor Core that is to receive the target Reactor Service.")]
        public string ToCoreName
        {
            get { return _toCoreName; }
            set
            {
                if (value == _toCoreName) return;

                _toCoreName = value;
                RaisePropertyChanged("ToCoreName");
            }
        }

        public ObservableCollection<string> AvailableCores { get; private set; }

        [Display(AutoGenerateField = false)]
        public bool IsBusy
        {
            get { return _isBusy; }
            set
            {
                if (value == _isBusy) return;

                _isBusy = value;
                RaisePropertyChanged("IsBusy");
            }
        }
    }
}
