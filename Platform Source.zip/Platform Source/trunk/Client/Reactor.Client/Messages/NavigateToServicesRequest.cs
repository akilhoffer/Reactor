﻿namespace Reactor.Client.Messages
{
    public class NavigateToServicesRequest
    {

    }
}
