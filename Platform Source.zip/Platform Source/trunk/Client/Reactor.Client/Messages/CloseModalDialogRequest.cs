﻿namespace Reactor.Client.Messages
{
    public class CloseModalDialogRequest
    {

    }
}
