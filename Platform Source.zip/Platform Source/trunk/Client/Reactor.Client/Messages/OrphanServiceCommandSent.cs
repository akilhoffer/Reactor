﻿namespace Reactor.Client.Messages
{
    public class OrphanServiceCommandSent
    {
        public string CoreName { get; set; }

        public string ServiceName { get; set; }

        public string ServiceVersion { get; set; }
    }
}
