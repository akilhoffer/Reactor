﻿namespace Reactor.Client.Messages
{
    public class TransferServiceCommandSent
    {
        public string ServiceName { get; set; }

        public string ServiceVersion { get; set; }

        public string FromCoreName { get; set; }

        public string ToCoreName { get; set; }
    }
}
