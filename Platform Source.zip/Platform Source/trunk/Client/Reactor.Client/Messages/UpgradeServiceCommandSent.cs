﻿namespace Reactor.Client.Messages
{
    public class UpgradeServiceCommandSent
    {
        public string ServiceName { get; set; }

        public string FromVersion { get; set; }

        public string ToVersion { get; set; }

        public string CoreName { get; set; }
    }
}
