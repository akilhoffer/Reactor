﻿using Reactor.Client.ViewModel;

namespace Reactor.Client.Messages
{
    public class CoreSelectedEvent
    {
        public CoreViewModel CoreViewModel { get; set; }
    }
}
