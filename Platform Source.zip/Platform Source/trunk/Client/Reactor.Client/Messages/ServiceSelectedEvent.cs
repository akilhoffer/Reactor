﻿using Reactor.Client.ViewModel;

namespace Reactor.Client.Messages
{
    public class ServiceSelectedEvent
    {
        public ServiceViewModel SelectedService { get; set; }
    }
}
