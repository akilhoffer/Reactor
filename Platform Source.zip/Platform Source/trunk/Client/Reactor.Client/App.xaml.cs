﻿using System;
using System.ServiceModel.DomainServices.Client.ApplicationServices;
using System.Windows;
using GalaSoft.MvvmLight.Threading;
using Microsoft.Practices.Unity;
using Reactor.Client.Controls;

namespace Reactor.Client
{
    /// <summary>
    /// Main <see cref="Application"/> class.
    /// </summary>
    public partial class App
    {
        private BusyIndicator _busyIndicator;

        /// <summary>
        /// Creates a new <see cref="App"/> instance.
        /// </summary>
        public App()
        {
            InitializeComponent();

            // Create a WebContext and add it to the ApplicationLifetimeObjects
            // collection.  This will then be available as WebContext.Current.
            WebContext webContext = new WebContext {Authentication = new FormsAuthentication()};
            //webContext.Authentication = new WindowsAuthentication();
            ApplicationLifetimeObjects.Add(webContext);

            DispatcherHelper.Initialize();
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var bootstrapper = new Bootstrapper();
            bootstrapper.Run();
            Container = bootstrapper.Container;

            // This will enable you to bind controls in XAML files to WebContext.Current
            // properties
            Resources.Add("WebContext", WebContext.Current);

            // This will automatically authenticate a user when using windows authentication
            // or when the user chose "Keep me signed in" on a previous login attempt
            WebContext.Current.Authentication.LoadUser(Application_UserLoaded, null);

            // Show some UI to the user while LoadUser is in progress
            _busyIndicator = new BusyIndicator
            {
                Content = new MainPage(),
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                VerticalContentAlignment = VerticalAlignment.Stretch
            };

            Current.RootVisual = _busyIndicator;
        }

        public static UnityContainer Container { get; set; }

        /// <summary>
        /// Invoked when the <see cref="LoadUserOperation"/> completes. Use this
        /// event handler to switch from the "loading UI" you created in
        /// <see cref="InitializeRootVisual" /> to the "application UI"
        /// </summary>
        private void Application_UserLoaded(LoadUserOperation operation)
        {
            
        }

        private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
        {
            // If the app is running outside of the debugger then report the exception using
            // a ChildWindow control.
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                // NOTE: This will allow the application to continue running after an exception has been thrown
                // but not handled. 
                // For production applications this error handling should be replaced with something that will 
                // report the error to the website and stop the application.
                e.Handled = true;
                ErrorWindow.CreateNew(e.ExceptionObject);
            }
        }
    }
}