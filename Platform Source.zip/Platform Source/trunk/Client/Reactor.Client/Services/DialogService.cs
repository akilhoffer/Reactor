﻿using System;
using Microsoft.Practices.Unity;
using Reactor.Client.ViewModel;
using Reactor.Client.Views;

namespace Reactor.Client.Services
{
    public interface IDialogService
    {
        void ShowAdoptServiceDialog();
        void ShowOrphanServiceDialog();
        void ShowTransferServiceDialog();
        void ShowUpgradeServiceDialog();
    }

    public class DialogService : IDialogService
    {
        private readonly IViewModelLocator _viewModelLocator;
        private readonly ModalDialog _modalDialog;

        /// <summary>
        /// Initializes a new instance of the <see cref="DialogService"/> class.
        /// </summary>
        /// <param name="viewModelLocator">The view model locator.</param>
        /// <param name="modalDialog">The modal dialog.</param>
        public DialogService(IViewModelLocator viewModelLocator, ModalDialog modalDialog)
        {
            if (viewModelLocator == null) throw new ArgumentNullException("viewModelLocator");
            if (modalDialog == null) throw new ArgumentNullException("modalDialog");

            _viewModelLocator = viewModelLocator;
            _modalDialog = modalDialog;
        }

        public void ShowAdoptServiceDialog()
        {
            var window = App.Container.Resolve<AdoptServiceWindow>();
            window.Show();
        }

        public void ShowOrphanServiceDialog()
        {
            _modalDialog.DataContext = _viewModelLocator.OrphanService;
            _modalDialog.Show();
        }

        public void ShowTransferServiceDialog()
        {
            _modalDialog.DataContext = _viewModelLocator.TransferService;
            _modalDialog.Show();
        }

        public void ShowUpgradeServiceDialog()
        {
            _modalDialog.DataContext = _viewModelLocator.UpgradeService;
            _modalDialog.Show();
        }
    }
}
