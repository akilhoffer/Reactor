﻿using GalaSoft.MvvmLight.Messaging;
using Microsoft.Practices.Unity;
using Reactor.Client.Services;
using Reactor.Client.ViewModel;

namespace Reactor.Client
{
    public class Bootstrapper
    {
        public UnityContainer Container { get; set; }

        public void Run()
        {
            Container = new UnityContainer();

            Container.RegisterInstance<IMessenger>(Messenger.Default);
            
            // Register an IReactorServiceAgent instance.
            // TODO: Make the IReactorServiceAgent configurable!
            Container.RegisterInstance<IReactorServiceAgent>(new DesignerServiceAgent(Messenger.Default));
            //Container.RegisterInstance<IReactorServiceAgent>(new ReactorServiceAgent());

            Container.RegisterType<IViewModelLocator, ViewModelLocator>();
            Container.RegisterType<IDialogService, DialogService>();

            // Singleton ViewModels
            Container.RegisterType<MainViewModel>(new ContainerControlledLifetimeManager());
            Container.RegisterType<HomeViewModel>(new ContainerControlledLifetimeManager());
        }
    }
}
