﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Reactor.Client.Controls
{
    public enum PixelFont
    {
        Pf11Px
    }

    internal static class PixelFonts
    {
        internal static readonly Dictionary<PixelFont, Dictionary<char, bool[,]>> Fonts;

        static PixelFonts()
        {
            Fonts = new Dictionary<PixelFont, Dictionary<char, bool[,]>>();

            string font = "A         B       C        D        E      F      G        H       I    J     K       L      M        N       O        P      Q        R       S       T        U       V        W          X         Y        Z       a      b      c      d      e      f     g      h      i  j    k      l  m          n      o      p      q      r     s      t     u      v      w        x      y      z     1      2      3      4        5      6      7      8      9      0      !  . |" +
                          "         .       .        .        .      .      .        .       .    .     .       .      .        .       .        .      .        .       .       .        .       .        .          .         .        .       .      .X     .      .    X .      .  XX .      .X     .X .  X .X     .X .          .      .      .      .      .     .      .     .      .      .        .      .      .     .      .      .      .        .      .      .      .      .      .      .  .  |" +
                          "   XX    .XXXX   .  XXXX  .XXXXX   .XXXXX .XXXXX .  XXXX  .X    X .XXX . XXX .X    X .X     .XX   XX .XX   X .  XXX   .XXXX  .  XXX   .XXXX   . XXXX  .XXXXXXX .X    X . X   X  .X   X   X . X    X  .X     X .XXXXXX .      .X     .      .    X .      . X   .      .X     .  .    .X     .X .          .      .      .      .      .     .      . X   .      .      .        .      .      .     .  X   . XXX  . XXX  .     X  .XXXXX .  XX  .XXXXX . XXX  . XXX  . XXX  .X .  |" +
                          "   XX    .X   X  . X    X .X    X  .X     .X     . X    X .X    X . X  .   X .X   X  .X     .XX   XX .XX   X . X   X  .X   X . X   X  .X   X  .X    X .   X    .X    X . X   X  .X   X   X . X    X  . X   X  .     X .      .X     .      .    X .      . X   .      .X     .  .    .X     .X .          .      .      .      .      .     .      . X   .      .      .        .      .      .     .XXX   .X   X .X   X .    XX  .X     . X    .    X .X   X .X   X .X   X .X .  |" +
                          "  X  X   .X   X  .X       .X     X .X     .X     .X       .X    X . X  .   X .X  X   .X     .X X X X .X X  X .X     X .X   X .X     X .X   X  .X      .   X    .X    X . X   X  . X X X X  .  X  X   .  X X   .    X  . XXX  .XXXX  . XXX  . XXXX . XXX  .XXXX . XXXX .XXXX  .X . XX .X   X .X .XXXX XXX  .XXXX  . XXX  .XXXX  . XXXX .X XX . XXX  .XXXX .X   X .X   X .X  X  X .X   X .X   X .XXXX .  X   .    X .    X .   X X  .X     .X     .   X  .X   X .X   X .X   X .X .  |" +
                          "  X  X   .XXXXX  .X       .X     X .XXXXX .XXXX  .X       .XXXXXX . X  .   X .X X    .X     .X X X X .X X  X .X     X .X   X .X     X .X   X  . XX    .   X    .X    X .  X X   . X X X X  .   XX    .   X    .   X   .    X .X   X .X   X .X   X .X   X . X   .X   X .X   X .X .  X .X  X  .X .X   X   X .X   X .X   X .X   X .X   X .XX   .X     . X   .X   X .X   X .X  X  X . X X  . X X  .   X .  X   .   X  .  XX  .  X  X  .XXXX  .XXXX  .   X  . XXX  . XXXX .X   X .X .  |" +
                          "  X  X   .X    X .X       .X     X .X     .X     .X   XXX .X    X . X  .   X .XXX    .X     .X  X  X .X  X X .X     X .XXXX  .X     X .XXXX   .   XX  .   X    .X    X .  X X   . X X X X  .   XX    .   X    .  X    . XXXX .X   X .X     .X   X .XXXXX . X   .X   X .X   X .X .  X .X X   .X .X   X   X .X   X .X   X .X   X .X   X .X    .XX    . X   .X   X . X X  .X X X X .  X   . X X  .  X  .  X   .  X   .    X . X   X  .    X .X   X .  X   .X   X .    X .X   X .X .  |" +
                          " XXXXXX  .X    X .X       .X     X .X     .X     .X     X .X    X . X  .   X .X  X   .X     .X  X  X .X  X X .X     X .X     .X     X .X  X   .     X .   X    .X    X .  X X   . X X X X  .  X  X   .   X    . X     .X   X .X   X .X     .X   X .X     . X   .X   X .X   X .X .  X .XXX   .X .X   X   X .X   X .X   X .X   X .X   X .X    .  XX  . X   .X   X . X X  .X X X X .  X   . X X  . X   .  X   . X    .    X . XXXXXX .    X .X   X .  X   .X   X .    X .X   X .X .  |" +
                          " X    X  .X    X . X    X .X    X  .X     .X     . X    X .X    X . X  .   X .X   X  .X     .X     X .X   XX . X   X  .X     . X   X  .X   X  .X    X .   X    .X    X .   X    .  X   X   . X    X  .   X    .X      .X   X .X   X .X   X .X   X .X   X . X   .X   X .X   X .X .  X .X  X  .X .X   X   X .X   X .X   X .X   X .X   X .X    .   XX . X   .X   X .  X   . X   X  . X X  .  X   .X    .  X   .X     .X   X .     X  .X   X .X   X . X    .X   X .   X  .X   X .  .X |" +
                          " X    X  .XXXXX  .  XXXX  .XXXXX   .XXXXX .X     .  XXXX  .X    X .XXX .XXX  .X    X .XXXXX .X     X .X   XX .  XXX   .X     .  XXX   .X    X . XXXX  .   X    . XXXX  .   X    .  X   X   . X    X  .   X    .XXXXXX . XXXX .XXXX  . XXX  . XXXX . XXX  . X   . XXXX .X   X .X .  X .X   X .X .X   X   X .X   X . XXX  .XXXX  . XXXX .X    .XXX   .  XX . XXXX .  X   . X   X  .X   X .  X   .XXXX .XXXXX .XXXXX . XXX  .     X  . XXX  . XXX  . X    . XXX  . XX   . XXX  .X .X |" +
                          "         .       .        .        .      .      .        .       .    .     .       .      .        .       .        .      .    X   .       .       .        .       .        .          .         .        .       .      .      .      .      .      .     .    X .      .  .  X .      .  .          .      .      .X     .    X .     .      .     .      .      .        .      .  X   .     .      .      .      .        .      .      .      .      .      .      .  .  |" +
                          "         .       .        .        .      .      .        .       .    .     .       .      .        .       .        .      .     XX .       .       .        .       .        .          .         .        .       .      .      .      .      .      .     . XXX  .      .  .XX  .      .  .          .      .      .X     .    X .     .      .     .      .      .        .      . X    .     .      .      .      .        .      .      .      .      .      .      .  .  |";

            Fonts.Add(PixelFont.Pf11Px, Parse(font, 4));
        }

        private static Dictionary<char, bool[,]> Parse(string font, int space)
        {
            var lines = font.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            var letters = lines[0].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x[0]).ToArray();
            var lengths = lines[1].Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Length).ToArray();

            var result = new Dictionary<char, bool[,]>(letters.Length);
            var offset = 0;

            for (int i = 0; i < letters.Length; i++)
            {
                var c = new bool[lengths[i], lines.Length - 1];

                for (int x = 0; x < lengths[i]; x++)
                {
                    for (int y = 0; y < lines.Length - 1; y++)
                    {
                        c[x, y] = lines[y + 1][offset + x] == 'X';
                    }
                }

                result.Add(letters[i], c);

                offset += lengths[i] + 1;
            }

            result.Add(' ', new bool[5, lines.Length - 1]);

            return result;
        }
    }
}
