﻿using System;
using System.Net;
using System.ServiceModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using GalaSoft.MvvmLight.Messaging;
using Reactor.Client.ViewModel;
using Reactor.Client.Views;

namespace Reactor.Client.Helpers
{
    public class DialogDispatcher
    {
        public DialogDispatcher()
        {
            Messenger.Default.Register<OpenDialog<ServicesViewModel>>(this, ReceiveMessage);
        }

        private void ReceiveMessage(OpenDialog<ServicesViewModel> msg)
        {
            switch (msg.Dialog)
            {
                case WellKnownDialogs.AddServicesDialog:


                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }

    public class OpenDialog<T>
    {
        public object Payload { get; set; }

        public WellKnownDialogs Dialog
        {
            get
            {
                if (typeof(T) == typeof(AdoptServiceViewModel))
                    return WellKnownDialogs.AddServicesDialog;

                throw new InvalidOperationException("No known dialog type for the ViewModel specified.");
            }
        }
    }

    public enum WellKnownDialogs
    {
        AddServicesDialog
    }
}
