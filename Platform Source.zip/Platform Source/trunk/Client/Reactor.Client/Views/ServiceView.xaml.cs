﻿using System.Windows.Input;

namespace Reactor.Client.Views
{
    public partial class ServiceView
    {
        public ServiceView()
        {
            InitializeComponent();
        }
    }
}
