﻿using System;
using GalaSoft.MvvmLight.Messaging;
using Reactor.Client.Messages;

namespace Reactor.Client.Views
{
    public partial class AdoptServiceWindow
    {
        private readonly IMessenger _messenger;

        public AdoptServiceWindow(IMessenger messenger)
        {
            _messenger = messenger;
            if (messenger == null) throw new ArgumentNullException("messenger");

            InitializeComponent();

            _messenger.Register<CloseAdoptionDialogRequest>(this, OnAdoptionDialogCloseRequestReceived);
        }

        private void OnAdoptionDialogCloseRequestReceived(CloseAdoptionDialogRequest obj)
        {
            _messenger.Unregister(this);

            Close();
        }
    }
}
