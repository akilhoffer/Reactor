﻿using Reactor.Client.ViewModel;
using System.Windows.Navigation;

namespace Reactor.Client
{
    /// <summary>
    /// Home page for the application.
    /// </summary>
    public partial class Home
    {
        /// <summary>
        /// Creates a new <see cref="Home"/> instance.
        /// </summary>
        public Home()
        {
            InitializeComponent();

            Title = ApplicationStrings.HomePageTitle;
        }

        public Home(HomeViewModel homeViewModel)
        {
            DataContext = homeViewModel;
        }

        /// <summary>
        /// Executes when the user navigates to this page.
        /// </summary>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }
    }
}