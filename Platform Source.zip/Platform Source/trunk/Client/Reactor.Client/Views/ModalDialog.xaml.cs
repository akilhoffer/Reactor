﻿using System;
using GalaSoft.MvvmLight.Messaging;
using Reactor.Client.Messages;

namespace Reactor.Client.Views
{
    public partial class ModalDialog
    {
        private readonly IMessenger _messenger;

        public ModalDialog(IMessenger messenger)
        {
            if (messenger == null) throw new ArgumentNullException("messenger");
            _messenger = messenger;

            InitializeComponent();

            _messenger.Register<CloseModalDialogRequest>(this, OnDialogCloseRequestReceived);
        }

        private void OnDialogCloseRequestReceived(CloseModalDialogRequest obj)
        {
            Close();
        }
    }
}
