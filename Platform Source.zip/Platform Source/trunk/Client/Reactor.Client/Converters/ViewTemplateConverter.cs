﻿using System;
using System.Globalization;
using System.Windows.Data;
using Reactor.Client.Models;
using OrphanServiceForm = Reactor.Client.Models.OrphanServiceForm;

namespace Reactor.Client.Converters
{
    public class ViewTemplateConverter : IValueConverter
    {
        /// <summary>
        /// Modifies the source data before passing it to the target for display in the UI.
        /// </summary>
        /// <returns>
        /// The value to be passed to the target dependency property.
        /// </returns>
        /// <param name="value">The source data being passed to the target.</param><param name="targetType">The <see cref="T:System.Type"/> of data expected by the target dependency property.</param><param name="parameter">An optional parameter to be used in the converter logic.</param><param name="culture">The culture of the conversion.</param>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value == null)
                throw new InvalidOperationException("Expected a model or viewmodel but subject was null instead.");

            if (value is OrphanServiceForm)
                return new Views.OrphanServiceForm { DataContext = value };
            
            if (value is UpgradeServiceForm)
                return new Views.UpgradeServiceForm { DataContext = value };

            if (value is TransferServiceForm)
                return new Views.TransferServiceForm { DataContext = value };

            throw new InvalidOperationException("There is no associated view for the provided model or viewmodel.");
        }

        /// <summary>
        /// Modifies the target data before passing it to the source object.  This method is called only in <see cref="F:System.Windows.Data.BindingMode.TwoWay"/> bindings.
        /// </summary>
        /// <returns>
        /// The value to be passed to the source object.
        /// </returns>
        /// <param name="value">The target data being passed to the source.</param><param name="targetType">The <see cref="T:System.Type"/> of data expected by the source object.</param><param name="parameter">An optional parameter to be used in the converter logic.</param><param name="culture">The culture of the conversion.</param>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
