﻿using System;
using System.Collections.Generic;
using System.Linq;
using GalaSoft.MvvmLight.Messaging;
using Reactor.Client.Models;
using Reactor.Client.Services;

namespace Reactor.Client.ViewModel
{
    public class TransferDialogViewModel : DialogViewModel
    {
        #region Fields

        private readonly IReactorServiceAgent _reactorServiceAgent;
        private readonly CoreViewModel _coreViewModel;
        private readonly ServiceViewModel _serviceViewModel;
        private readonly TransferServiceForm _transferServiceForm;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="TransferDialogViewModel"/> class.
        /// </summary>
        /// <param name="messenger">The messenger.</param>
        /// <param name="reactorServiceAgent">The reactor service agent.</param>
        /// <param name="coreViewModel">The core view model.</param>
        /// <param name="serviceViewModel">The service view model.</param>
        /// <param name="transferServiceForm">The transfer service form.</param>
        public TransferDialogViewModel(IMessenger messenger, IReactorServiceAgent reactorServiceAgent, CoreViewModel coreViewModel, ServiceViewModel serviceViewModel, TransferServiceForm transferServiceForm) : base(messenger)
        {
            if (reactorServiceAgent == null) throw new ArgumentNullException("reactorServiceAgent");
            if (coreViewModel == null) throw new ArgumentNullException("coreViewModel");
            if (serviceViewModel == null) throw new ArgumentNullException("serviceViewModel");
            if (transferServiceForm == null) throw new ArgumentNullException("transferServiceForm");

            _reactorServiceAgent = reactorServiceAgent;
            _coreViewModel = coreViewModel;
            _serviceViewModel = serviceViewModel;
            _transferServiceForm = transferServiceForm;

            SetupForm();
        }

        protected override void OnSubmit()
        {
            var cmd = new TransferServiceCommand
                          {
                              FromCoreName = _coreViewModel.Name,
                              ServiceName = _serviceViewModel.Name,
                              ServiceVersion = _serviceViewModel.Version,
                              ToCoreName = _transferServiceForm.ToCoreName
                          };
            _reactorServiceAgent.SendTransferCommand(cmd, OnSubmitted);
        }

        private void SetupForm()
        {
            FormContent = _transferServiceForm;
            _transferServiceForm.ServiceName = _serviceViewModel.Name;
            _transferServiceForm.ServiceVersion = _serviceViewModel.Version;
            _transferServiceForm.FromCoreName = _coreViewModel.Name;

            _reactorServiceAgent.GetAllReactorCores(LoadCores);

            _transferServiceForm.PropertyChanged += (s, e) =>
                                                        {
                                                            if(e.PropertyName != "ToCoreName") return;

                                                            CanSave = !string.IsNullOrEmpty(_transferServiceForm.ToCoreName);
                                                        };
        }

        private void LoadCores(IEnumerable<CoreViewModel> obj)
        {
            foreach (var coreViewModel in obj.Where(c => c.Name != _coreViewModel.Name))
                _transferServiceForm.AvailableCores.Add(coreViewModel.Name);
        }

        private void OnSubmitted()
        {
            IsBusy = false;
            OnCancel();
        }
    }
}
