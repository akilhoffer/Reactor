﻿using System;
using GalaSoft.MvvmLight;
using Reactor.Client.Web.Data;

namespace Reactor.Client.ViewModel
{
    public class ServicePackageViewModel : ViewModelBase
    {
        #region Fields

        private readonly ServicePackageInfo _info;
        private string _name;
        private string _version;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="ServicePackageViewModel"/> class.
        /// </summary>
        /// <param name="info">The info.</param>
        public ServicePackageViewModel(ServicePackageInfo info)
        {
            if (info == null) throw new ArgumentNullException("info");

            _info = info;
            _name = info.Name;
            _version = info.Version;
        }

        public string DisplayName
        {
            get { return string.Format("{0} v{1}", _info.Name, _info.Version); }
        }

        public string Name
        {
            get { return _name; }
            set
            {
                if (value == _name) return;

                _name = value;
                RaisePropertyChanged("Name");
            }
        }

        public string Version
        {
            get { return _version; }
            set
            {
                if (value == _version) return;

                _version = value;
                RaisePropertyChanged("Version");
            }
        }
    }
}
