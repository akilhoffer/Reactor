using System;
using System.Windows.Browser;
using GalaSoft.MvvmLight;

namespace Reactor.Client.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        private string _applicationSubTitle;

        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public MainViewModel()
        {
            ParseUrl();
        }

        private void ParseUrl()
        {
            ApplicationSubTitle = string.Format("management interface via {0}", HtmlPage.Document.DocumentUri.Host);
        }

        public string ApplicationSubTitle
        {
            get { return _applicationSubTitle; }
            set
            {
                if (value == _applicationSubTitle) return;

                _applicationSubTitle = value;
                RaisePropertyChanged("ApplicationSubTitle");
            }
        }
    }
}