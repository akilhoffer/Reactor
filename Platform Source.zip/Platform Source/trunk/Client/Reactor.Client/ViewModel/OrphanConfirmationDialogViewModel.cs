﻿using System;
using GalaSoft.MvvmLight.Messaging;
using Reactor.Client.Models;
using Reactor.Client.Services;

namespace Reactor.Client.ViewModel
{
    public class OrphanConfirmationDialogViewModel : DialogViewModel
    {
        private readonly IReactorServiceAgent _reactorServiceAgent;
        private readonly CoreViewModel _coreViewModel;
        private readonly ServiceViewModel _serviceViewModel;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrphanConfirmationDialogViewModel"/> class.
        /// </summary>
        /// <param name="messenger">The messenger.</param>
        /// <param name="reactorServiceAgent">The reactor service agent.</param>
        /// <param name="coreViewModel">The core view model.</param>
        /// <param name="serviceViewModel">The service view model.</param>
        /// <param name="orphanServiceForm">The orphan service form.</param>
        public OrphanConfirmationDialogViewModel(IMessenger messenger, IReactorServiceAgent reactorServiceAgent, CoreViewModel coreViewModel, ServiceViewModel serviceViewModel, OrphanServiceForm orphanServiceForm) : base(messenger)
        {
            if (reactorServiceAgent == null) throw new ArgumentNullException("reactorServiceAgent");
            if (coreViewModel == null) throw new ArgumentNullException("coreViewModel");
            if (serviceViewModel == null) throw new ArgumentNullException("serviceViewModel");
            if (orphanServiceForm == null) throw new ArgumentNullException("serviceViewModel");

            _reactorServiceAgent = reactorServiceAgent;
            _coreViewModel = coreViewModel;
            _serviceViewModel = serviceViewModel;

            orphanServiceForm.CoreName = coreViewModel.Name;
            orphanServiceForm.ServiceDisplay = string.Format("{0} {1}", serviceViewModel.Name, serviceViewModel.Version);

            FormContent = orphanServiceForm;

            CanSave = true;
        }

        protected override void OnSubmit()
        {
            IsBusy = true;
            _reactorServiceAgent.SendOrphanCommand(new OrphanServiceCommand
                                                       {
                                                           CoreName = _coreViewModel.Name, 
                                                           ServiceName = _serviceViewModel.Name, 
                                                           ServiceVersion = _serviceViewModel.Version
                                                       }, OnSubmitted);
        }

        private void OnSubmitted()
        {
            IsBusy = false;
            OnCancel();
        }
    }
}
