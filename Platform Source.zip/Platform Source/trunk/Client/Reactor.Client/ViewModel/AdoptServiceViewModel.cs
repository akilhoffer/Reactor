﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Input;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using Reactor.Client.Messages;
using Reactor.Client.Models;
using Reactor.Client.Services;

namespace Reactor.Client.ViewModel
{
    public class AdoptServiceViewModel : ViewModelBase
    {
        private bool _isSendingAdoptionCommand;
        private readonly IReactorServiceAgent _reactorServiceAgent;
        private readonly IMessenger _messenger;
        private AdoptionModel _adoptionModel;

        public AdoptServiceViewModel(IReactorServiceAgent reactorServiceAgent, IMessenger messenger, CoreViewModel coreViewModel)
        {
            if (reactorServiceAgent == null) throw new ArgumentNullException("reactorServiceAgent");
            if (messenger == null) throw new ArgumentNullException("messenger");
            if (coreViewModel == null) throw new ArgumentNullException("coreViewModel");

            _reactorServiceAgent = reactorServiceAgent;
            _messenger = messenger;
            AdoptionModel = new AdoptionModel {CoreName = coreViewModel.Name};
        }

        public AdoptionModel AdoptionModel
        {
            get { return _adoptionModel; }
            set
            {
                if (value == _adoptionModel) return;

                _adoptionModel = value;
                RaisePropertyChanged("AdoptionModel");

                _reactorServiceAgent.GetAllServicePackages(RetrieveServicePackages);
            }
        }

        public ICommand SendAdoptionCommand
        {
            get { return new RelayCommand(SendAdoptionCommandInternal); }
        }

        public ICommand CancelAdoption
        {
            get { return new RelayCommand(CancelAdoptionInternal); }
        }

        private void CancelAdoptionInternal()
        {
            SendDialogCloseRequest();
        }

        private void SendAdoptionCommandInternal()
        {
            IsSendingAdoptionCommand = true;

            // TODO: Send adoption command!

            SendDialogCloseRequest();
        }

        private void SendDialogCloseRequest()
        {
            _messenger.Send(new CloseAdoptionDialogRequest());
        }

        private void RetrieveServicePackages(IEnumerable<ServicePackageViewModel> servicePackages)
        {
            _adoptionModel.ServicePackages = servicePackages;

            if(servicePackages.Any())
                _adoptionModel.SelectedServicePackage = servicePackages.First();
        }

        public bool IsSendingAdoptionCommand
        {
            get { return _isSendingAdoptionCommand; }
            set
            {
                if (value == _isSendingAdoptionCommand) return;

                _isSendingAdoptionCommand = value;
                RaisePropertyChanged("IsSendingAdoptionCommand");
            }
        }
    }
}
