﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using GalaSoft.MvvmLight.Threading;
using Reactor.Client.Messages;
using Reactor.Client.Services;
using Reactor.Client.Web.Data;

namespace Reactor.Client.ViewModel
{
    public class ServiceViewModel : ServiceBaseViewModel
    {
        #region Fields

        private readonly IMessenger _messenger;
        private readonly IDialogService _dialogService;
        private readonly IReactorServiceAgent _serviceAgent;

        private Service _service;
        private object _playButtonImage;
        private object _stopButtonImage;
        private string _actionPendingMessage;
        private Visibility _actionPendingVisibility;
        private Timer _pendingOperationAlertTimer;

        private const string PendingOperationDisclaimer = "Please note that the entire process can take several minutes to complete.";

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceViewModel"/> class.
        /// </summary>
        /// <param name="messenger">The messenger.</param>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="serviceAgent">The service agent.</param>
        /// <param name="service">The service.</param>
        public ServiceViewModel(IMessenger messenger, IDialogService dialogService, IReactorServiceAgent serviceAgent, Service service) : base(serviceAgent)
        {
            if (messenger == null) throw new ArgumentNullException("messenger");
            if (dialogService == null) throw new ArgumentNullException("dialogService");
            if (serviceAgent == null) throw new ArgumentNullException("serviceAgent");
            if (service == null) throw new ArgumentNullException("service");

            _messenger = messenger;
            _dialogService = dialogService;
            _serviceAgent = serviceAgent;

            ServicePackages = new ObservableCollection<ServicePackageViewModel>();
            _actionPendingVisibility = Visibility.Collapsed;

            LoadService(service);

            PropertyChanged += (s,e) =>
                                   {
                                       if (e.PropertyName != "IsOnline") return;
                                       UpdateControlButtons();
                                   };

            messenger.Register<OrphanServiceCommandSent>(this, OnOrphanCommandSent);
            messenger.Register<TransferServiceCommandSent>(this, OnTransferCommandSent);
            messenger.Register<UpgradeServiceCommandSent>(this, OnUpgradeCommandSent);

            DetermineOnlineStatus();
            UpdateStatusImage();
        }

        private void UpdateControlButtons()
        {
            if (IsOnline)
            {
                PlayButtonImage = new BitmapImage(new Uri(Application.Current.Host.Source, "../Images/control_play_blue.png"));
                StopButtonImage = new BitmapImage(new Uri(Application.Current.Host.Source, "../Images/control_stop.png"));
            }
            else
            {
                PlayButtonImage = new BitmapImage(new Uri(Application.Current.Host.Source, "../Images/control_play.png"));
                StopButtonImage = new BitmapImage(new Uri(Application.Current.Host.Source, "../Images/control_stop_blue.png"));
            }
        }

        public object StopButtonImage
        {
            get { return _stopButtonImage; }
            set
            {
                if (value == _stopButtonImage) return;

                _stopButtonImage = value;
                RaisePropertyChanged("StopButtonImage");
            }
        }

        public object PlayButtonImage
        {
            get { return _playButtonImage; }
            set
            {
                if (value == _playButtonImage) return;

                _playButtonImage = value;
                RaisePropertyChanged("PlayButtonImage");
            }
        }

        public object ActionPendingImage
        {
            get { return new Uri(Application.Current.Host.Source, "/Images/dashboard--exclamation.png"); }
        }

        public ICommand TransferCommand
        {
            get { return new RelayCommand(HandleTransferCommand); }
        }

        public ICommand OrphanCommand
        {
            get { return new RelayCommand(HandleOrphanCommand); }
        }

        public ICommand UpgradeCommand
        {
            get { return new RelayCommand(HandleUpgradeCommand); }
        }

        public string ActionPendingMessage
        {
            get { return _actionPendingMessage; }
            set
            {
                if (value == _actionPendingMessage) return;

                _actionPendingMessage = value;
                RaisePropertyChanged("ActionPendingMessage");
            }
        }

        public Visibility ActionPendingVisibility
        {
            get { return _actionPendingVisibility; }
            set
            {
                if (value == _actionPendingVisibility) return;

                _actionPendingVisibility = value;
                RaisePropertyChanged("ActionPendingVisibility");
            }
        }

        public ObservableCollection<ServicePackageViewModel> ServicePackages { get; private set; }

        public void LoadService(Service service)
        {
            if (service == null) throw new ArgumentNullException("service");

            _service = service;

            Name = service.Name;
            Version = service.Version;
            VersionDisplay = string.Format("v{0}", service.Version);

            _serviceAgent.GetAllServicePackages(LoadServicePackages);
        }

        protected override void DetermineOnlineStatus()
        {
            var interval = TimeSpan.FromMinutes(1);
            if (HealthCheckInterval.HasValue)
                interval = HealthCheckInterval.Value;

            var pastInterval = (DateTime.Now - _service.LastSeen) > interval;
            IsOnline = !pastInterval;
        }

        protected override void UpdateStatusTooltip()
        {
            OnlineStatusMessage = IsOnline ? CreateOnlineMessage() : CreateOfflineMessage();
        }

        #region Private Methods

        private void LoadServicePackages(IEnumerable<ServicePackageViewModel> servicePackages)
        {
            var packagesForCurrentService = servicePackages.Where(s => s.Name == Name);

            if (!packagesForCurrentService.Any()) return;

            var currentVersion = new Version(Version);
            foreach (var servicePackageViewModel in packagesForCurrentService)
            {
                var version = new Version(servicePackageViewModel.Version);

                if (version > currentVersion)
                    ServicePackages.Add(servicePackageViewModel);
            }
        }

        private void HandleTransferCommand()
        {
            SendSelectedEvent();

            _dialogService.ShowTransferServiceDialog();
        }

        private void HandleOrphanCommand()
        {
            SendSelectedEvent();

            _dialogService.ShowOrphanServiceDialog();
        }

        private void HandleUpgradeCommand()
        {
            SendSelectedEvent();

            _dialogService.ShowUpgradeServiceDialog();
        }

        private void SendSelectedEvent()
        {
            _messenger.Send(new ServiceSelectedEvent {SelectedService = this});
        }

        private void CreateAndStartPendingOperationAlertTimer()
        {
            if (_pendingOperationAlertTimer != null)
                _pendingOperationAlertTimer.Dispose();

            _pendingOperationAlertTimer = new Timer(PendingOperationAlertTimerElapsed, null, TimeSpan.FromSeconds(60), TimeSpan.FromMilliseconds(-1));
        }

        private void PendingOperationAlertTimerElapsed(object obj)
        {
            DispatcherHelper.CheckBeginInvokeOnUI(() =>
                                                      {
                                                          ActionPendingMessage = string.Empty;
                                                          ActionPendingVisibility = Visibility.Collapsed;
                                                      });

            _pendingOperationAlertTimer.Dispose();
            _pendingOperationAlertTimer = null;
        }

        #region Message Receipt Handlers

        private void OnUpgradeCommandSent(UpgradeServiceCommandSent msg)
        {
            // Don't handle this event if it didnt originate from this instance
            if(msg.ServiceName != Name || msg.FromVersion != Version || _service.CoreName != msg.CoreName) return;

            ActionPendingVisibility = Visibility.Visible;
            ActionPendingMessage = string.Format("- There is a pending upgrade in progress for this service.{3}- Upgrade is to be from v{0} to v{1}.{3}- {2}", msg.FromVersion, msg.ToVersion, PendingOperationDisclaimer, Environment.NewLine);

            CreateAndStartPendingOperationAlertTimer();
        }

        private void OnTransferCommandSent(TransferServiceCommandSent msg)
        {
            // Don't handle this event if it didnt originate from this instance
            if(msg.ServiceName != Name || msg.ServiceVersion != Version || _service.CoreName != msg.FromCoreName) return;

            ActionPendingVisibility = Visibility.Visible;
            ActionPendingMessage = string.Format("- There is a pending transfer in progress for this service.{3}- The service is to be transferred from {0} {1}.{3}- {2}", msg.FromCoreName, msg.ToCoreName, PendingOperationDisclaimer, Environment.NewLine);

            CreateAndStartPendingOperationAlertTimer();
        }

        private void OnOrphanCommandSent(OrphanServiceCommandSent msg)
        {
            // Don't handle this event if it didnt originate from this instance
            if(msg.ServiceName != Name || msg.ServiceVersion != Version || _service.CoreName != msg.CoreName) return;

            ActionPendingVisibility = Visibility.Visible;
            ActionPendingMessage = string.Format("- There is a pending orphan operation in progress for this service.{1}- {0}", PendingOperationDisclaimer, Environment.NewLine);

            CreateAndStartPendingOperationAlertTimer();
        }

        #endregion

        #endregion
    }
}
