﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;
using GalaSoft.MvvmLight;
using Reactor.Client.Services;

namespace Reactor.Client.ViewModel
{
    public abstract class ServiceBaseViewModel : ViewModelBase
    {
        #region Fields

        protected readonly IReactorServiceAgent ServiceAgent;
        private string _name;
        private string _version;
        private string _versionDisplay;
        private string _onlineStatusMessage;

        private DateTime? _lastSeen;
        private bool? _isOnline;
        private object _statusImage;

        protected const string HealthCheckNote = "- Determined by comparing last seen time to the configured health check interval";

        public TimeSpan? HealthCheckInterval;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceBaseViewModel"/> class.
        /// </summary>
        /// <param name="serviceAgent">The service agent.</param>
        protected ServiceBaseViewModel(IReactorServiceAgent serviceAgent)
        {
            if (serviceAgent == null) throw new ArgumentNullException("serviceAgent");

            ServiceAgent = serviceAgent;

            serviceAgent.GetConfigurationValue("HealthCheckInterval", SetHealthCheckInterval);

            PropertyChanged += (s, e) =>
            {
                if (e.PropertyName != "IsOnline") return;

                UpdateStatusImage();
                UpdateStatusTooltip();
            };
        }

        private void SetHealthCheckInterval(string value)
        {
            TimeSpan tmp;
            if(!TimeSpan.TryParse(value, out tmp))
                tmp = TimeSpan.FromMinutes(1);

            HealthCheckInterval = tmp;
        }

        public object StatusImage
        {
            get { return _statusImage; }
            set
            {
                if (value == _statusImage) return;

                _statusImage = value;
                RaisePropertyChanged("StatusImage");
            }
        }

        public bool IsOnline
        {
            get { return (_isOnline.HasValue) ? _isOnline.Value : false; }
            set
            {
                if (value == _isOnline) return;

                _isOnline = value;
                RaisePropertyChanged("IsOnline");
            }
        }

        public DateTime? LastSeen
        {
            get { return _lastSeen; }
            set
            {
                if (value == _lastSeen) return;

                _lastSeen = value;
                RaisePropertyChanged("LastSeen");
            }
        }

        public string Version
        {
            get { return _version; }
            set
            {
                if (value == _version) return;

                _version = value;
                RaisePropertyChanged("Version");
            }
        }

        public string VersionDisplay
        {
            get { return _versionDisplay; }
            set
            {
                if (value == _versionDisplay) return;

                _versionDisplay = value;
                RaisePropertyChanged("VersionDisplay");
            }
        }

        public string Name
        {
            get { return _name; }
            set
            {
                if (value == _name) return;

                _name = value;
                RaisePropertyChanged("Name");
            }
        }

        public string OnlineStatusMessage
        {
            get { return _onlineStatusMessage; }
            set
            {
                if (value == _onlineStatusMessage) return;

                _onlineStatusMessage = value;
                RaisePropertyChanged("OnlineStatusMessage");
            }
        }

        protected abstract void DetermineOnlineStatus();

        protected abstract void UpdateStatusTooltip();

        protected string CreateOnlineMessage()
        {
            return string.Format("- Online{0}{1}{0}{2}", Environment.NewLine, HealthCheckNote, CreateIntervalDisplay());
        }

        protected string CreateOfflineMessage()
        {
            return string.Format("- Offline{0}{1}{0}{2}", Environment.NewLine, HealthCheckNote, CreateIntervalDisplay());
        }

        protected string CreateIntervalDisplay()
        {
            var timespan = (HealthCheckInterval.HasValue) ? HealthCheckInterval.Value : TimeSpan.FromMinutes(1);

            return string.Format("- Configured health check interval: {0} minutes and {1} seconds", timespan.Minutes, timespan.Seconds);
        }

        protected virtual void UpdateStatusImage()
        {
            StatusImage = IsOnline 
                ? new BitmapImage(new Uri(Application.Current.Host.Source, "../Images/StatusLight-Green.png")) 
                : new BitmapImage(new Uri(Application.Current.Host.Source, "../Images/StatusLight-Red.png"));
        }
    }
}
