﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using GalaSoft.MvvmLight;
using Reactor.Client.Services;

namespace Reactor.Client.ViewModel
{
    public class ServicesViewModel : ViewModelBase
    {
        #region Fields

        private readonly CoreViewModel _coreViewModel;
        private string _pageTitle;

        #endregion

        public ServicesViewModel(CoreViewModel coreViewModel)
        {
            if (coreViewModel == null) throw new ArgumentNullException("coreViewModel");

            _coreViewModel = coreViewModel;

            PageTitle = string.Format("Services managed by {0}", _coreViewModel.Name);
        }

        public string PageTitle
        {
            get { return _pageTitle; }
            set
            {
                if (value == _pageTitle) return;

                _pageTitle = value;
                RaisePropertyChanged("PageTitle");
            }
        }

        public ObservableCollection<ServiceViewModel> Services
        {
            get { return _coreViewModel.Services; }
        }
    }
}
