﻿using System;
using System.Linq;
using GalaSoft.MvvmLight.Messaging;
using Reactor.Client.Models;
using Reactor.Client.Services;

namespace Reactor.Client.ViewModel
{
    public class UpgradeDialogViewModel : DialogViewModel
    {
        #region Fields

        private readonly IReactorServiceAgent _reactorServiceAgent;
        private readonly CoreViewModel _coreViewModel;
        private readonly ServiceViewModel _serviceViewModel;
        private readonly UpgradeServiceForm _upgradeServiceForm;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="UpgradeDialogViewModel"/> class.
        /// </summary>
        /// <param name="messenger">The messenger.</param>
        /// <param name="reactorServiceAgent">The reactor service agent.</param>
        /// <param name="coreViewModel">The core view model.</param>
        /// <param name="serviceViewModel">The service view model.</param>
        /// <param name="upgradeServiceForm">The upgrade service form.</param>
        public UpgradeDialogViewModel(IMessenger messenger, IReactorServiceAgent reactorServiceAgent, CoreViewModel coreViewModel, ServiceViewModel serviceViewModel, UpgradeServiceForm upgradeServiceForm) : base(messenger)
        {
            if (reactorServiceAgent == null) throw new ArgumentNullException("reactorServiceAgent");
            if (coreViewModel == null) throw new ArgumentNullException("coreViewModel");
            if (serviceViewModel == null) throw new ArgumentNullException("serviceViewModel");
            if (upgradeServiceForm == null) throw new ArgumentNullException("upgradeServiceForm");

            _reactorServiceAgent = reactorServiceAgent;
            _coreViewModel = coreViewModel;
            _serviceViewModel = serviceViewModel;
            _upgradeServiceForm = upgradeServiceForm;

            SetupForm();
        }

        private void SetupForm()
        {
            _upgradeServiceForm.CoreName = _coreViewModel.Name;
            _upgradeServiceForm.ServiceName = _serviceViewModel.Name;
            _upgradeServiceForm.FromVersion = _serviceViewModel.Version;
            FormContent = _upgradeServiceForm;

            if(!_serviceViewModel.ServicePackages.Any()) return;

            foreach (var servicePackageViewModel in _serviceViewModel.ServicePackages)
                _upgradeServiceForm.PossibleUpgradeVersions.Add(servicePackageViewModel.Version);

            _upgradeServiceForm.PropertyChanged += (s, e) =>
                                                       {
                                                           if (e.PropertyName != "ToVersion") return;

                                                           CanSave = !string.IsNullOrEmpty(_upgradeServiceForm.ToVersion);
                                                       };

            _upgradeServiceForm.ToVersion = _upgradeServiceForm.PossibleUpgradeVersions[0];
        }

        protected override void OnSubmit()
        {
            IsBusy = true;
            _reactorServiceAgent.SendUpgradeServiceCommand(new UpgradeServiceCommand
                                                               {
                                                                   CoreName = _coreViewModel.Name, 
                                                                   ServiceName = _serviceViewModel.Name, 
                                                                   FromVersion = _serviceViewModel.Version,
                                                                   ToVersion = _upgradeServiceForm.ToVersion
                                                               }, OnSubmitted);
        }

        private void OnSubmitted()
        {
            IsBusy = false;
            OnCancel();
        }
    }
}
