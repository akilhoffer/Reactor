﻿using MassTransit;

namespace Reactor
{
    public static class ServiceBusExtensions
    {
        public static void Shutdown(this IServiceBus serviceBus)
        {
            serviceBus.Dispose();
        }
    }
}
