﻿using System.IO;

namespace Reactor.Extensions
{
    public static class DirectoryExtensions
    {
        public static void CopyContentsTo(this DirectoryInfo directoryInfo, string destination)
        {
            foreach (var file in directoryInfo.EnumerateFiles())
                file.CopyTo(Path.Combine(destination, file.Name));

            foreach (var directory in directoryInfo.EnumerateDirectories())
            {
                var newDirectory = Directory.CreateDirectory(Path.Combine(destination, directory.Name));
                directory.CopyContentsTo(newDirectory.FullName);
            }
        }
    }
}
