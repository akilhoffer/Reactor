﻿namespace Reactor.Environment
{
    public static class WellKnownExecutionEnvironments
    {
        public static readonly string Development = "Development";
        public static readonly string Test = "Test";
        public static readonly string Staging = "Staging";
        public static readonly string Production = "Production";
    }
}
