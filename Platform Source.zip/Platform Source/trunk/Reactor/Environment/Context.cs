﻿using MassTransit;
using Microsoft.Practices.ServiceLocation;
using Reactor.Configuration;
using Reactor.ServiceGrid;

namespace Reactor.Environment
{
    public class Context
    {
        /// <summary>
        /// Initializes the <see cref="Context"/> class.
        /// </summary>
        static Context()
        {
            GridContext = new GridContext();
        }

        /// <summary>
        /// Gets or sets the IContainer instance to be used throughout Reactor.
        /// </summary>
        /// <value>The container.</value>
        public static IServiceLocator ServiceLocator { get; set; }

        /// <summary>
        /// Gets or sets the service bus.
        /// </summary>
        /// <value>The service bus.</value>
        public static IServiceBus ServiceBus { get; set; }

        /// <summary>
        /// Gets or sets the configuration aggregator.
        /// </summary>
        /// <value>The configuration.</value>
        public static IConfigurationAggregator Configuration { get; set; }

        /// <summary>
        /// Gets or sets the grid context.
        /// </summary>
        /// <value>The grid context.</value>
        public static IGridContext GridContext { get; private set; }
    }
}
