﻿using Reactor.Configuration;
using Samurai.Wakizashi.Workflow;

namespace Reactor.Environment.Workflows
{
    public class InitializationContext : IWorkflowContext
    {
        public BrokerConnectionDetails BrokerDetails { get; set; }
        public string DatabaseConnectionString { get; set; }
        public string PackageRepositoryLocation { get; set; }
        public IConfigurationStore ConfigurationStore { get; set; }
    }
}
