﻿using System;
using log4net;
using Reactor.Configuration;

namespace Reactor.Customization
{
    public class LogCustomizationManager : CustomizationManagerBase<ICustomizeLogging>
    {
        private static ILog _log;

        /// <summary>
        /// Initializes a new instance of the <see cref="LogCustomizationManager"/> class.
        /// </summary>
        public LogCustomizationManager() : base(AppDomain.CurrentDomain.BaseDirectory)
        {
            _log = LogManager.GetLogger(GetType());
        }

        /// <summary>
        /// Runs all customers found by this instance.
        /// </summary>
        public override void RunAll()
        {
            foreach (var customizer in Customizers)
            {
                if (_log.IsDebugEnabled) _log.DebugFormat("Executing log customizer: {0}", customizer.GetType().FullName);       
                customizer.Customize();
            }
        }
    }
}
