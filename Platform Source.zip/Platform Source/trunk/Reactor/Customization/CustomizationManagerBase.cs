﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using log4net;

namespace Reactor.Customization
{
    public abstract class CustomizationManagerBase<T> where T : class 
    {
        protected static ILog Log;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomizationManagerBase&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="folder">The folder to scan for customizers.</param>
        protected CustomizationManagerBase(string folder)
        {
            Log = LogManager.GetLogger(GetType());

            Customizers = new List<T>();

            using (var directoryCatalog = new DirectoryCatalog(folder))
            {
                using(var container = new CompositionContainer(directoryCatalog))
                {
                    container.ComposeParts(this);
                }
            }

            if (Log.IsDebugEnabled) Log.DebugFormat("There were {0} customizers found", Customizers.Count);
        }

        /// <summary>
        /// Runs all customers found by this instance.
        /// </summary>
        public abstract void RunAll();

        [ImportMany(AllowRecomposition = true)]
        public List<T> Customizers { get; protected set; }
    }
}
