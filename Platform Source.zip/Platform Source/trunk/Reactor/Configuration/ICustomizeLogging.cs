﻿namespace Reactor.Configuration
{
    public interface ICustomizeLogging
    {
        /// <summary>
        /// Customizes logging.
        /// </summary>
        void Customize();
    }
}
