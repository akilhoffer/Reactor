﻿namespace Reactor.Configuration
{
    /// <summary>
    /// Contains a key/value pair representing a single configuration element.
    /// </summary>
    public class ConfigurationElement
    {
        /// <summary>
        /// Gets or sets the element key.
        /// </summary>
        /// <value>The key.</value>
        public string Key { get; set; }

        /// <summary>
        /// Gets or sets the configuration value in string format.
        /// </summary>
        /// <value>The value.</value>
        public string Value { get; set; }
    }
}
