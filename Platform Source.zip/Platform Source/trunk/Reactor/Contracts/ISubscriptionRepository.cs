﻿using System.Collections.Generic;
using Reactor.Entities;

namespace Reactor.Contracts
{
    public interface ISubscriptionRepository
    {
        List<Subscription> GetAllSubscriptions();
    }
}
