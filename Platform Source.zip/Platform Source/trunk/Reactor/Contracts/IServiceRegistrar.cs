﻿namespace Reactor.Contracts
{
    public interface IServiceRegistrar
    {
        /// <summary>
        /// Registers a single instance that is to be returned when the specified type is requested..
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instance">The instance.</param>
        void RegisterInstance<T>(object instance) where T : class;

        /// <summary>
        /// Registers the a concrete type to associate with the abstract type.
        /// </summary>
        /// <typeparam name="T">Abstract type</typeparam>
        /// <typeparam name="TConcrete">The concrete type to instantiate when the abstract type is requested.</typeparam>
        void RegisterType<T, TConcrete>() where TConcrete : T;
    }
}
