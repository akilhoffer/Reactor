﻿namespace Reactor.Contracts
{
    /// <summary>
    /// Marker interface to faciliate discoverability of Reactor Extensions.
    /// </summary>
    public interface IReactorExtension
    {
        /// <summary>
        /// Starts this extension.
        /// </summary>
        void Start();

        /// <summary>
        /// Stops this instance.
        /// </summary>
        void Stop();
    }
}
