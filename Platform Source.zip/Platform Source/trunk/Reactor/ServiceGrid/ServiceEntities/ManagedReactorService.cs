﻿using System;
using MassTransit;
using Reactor.Environment;
using Reactor.Exceptions;

namespace Reactor.ServiceGrid.ServiceEntities
{
    public abstract class ManagedReactorService : ReactorServiceBase
    {
        protected ManagedReactorService(IServiceBus serviceBus) : base(serviceBus)
        {
            if(Context.GridContext.ServiceIdentifier == null)
                throw new FatalException("No ServiceIdentifier found to create service with.");

            Identifier = Context.GridContext.ServiceIdentifier;
            InstanceIdentifier = Context.GridContext.ServiceInstanceIdentifier;
        }

        #region Overrides of ReactorServiceBase

        public override void Start()
        {
            base.Start();

            OnStarted();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1065:DoNotRaiseExceptionsInUnexpectedLocations")]
        public override Uri PrimaryEndpointUri
        {
            get { throw new NotImplementedException(); }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the service instance identifier.
        /// </summary>
        /// <value>The service instance identifier.</value>
        public Guid InstanceIdentifier { get; set; }

        #endregion

        /// <summary>
        /// Called when the service is started. This signals concrete implementations to perform their 
        /// intended purpose.
        /// </summary>
        protected abstract void OnStarted();
    }
}
