﻿using System;
using System.Collections.Generic;
using System.ServiceProcess;
using Reactor.Entities;
using Reactor.Messages.Commands.Core;
using Reactor.Messages.Events.Adoptions;

namespace Reactor.ServiceGrid
{
    public interface IReactorCore : IReactorService
    {
        /// <summary>
        /// Gets entities representing all the services managed by this instance.
        /// </summary>
        /// <value>The services.</value>
        IEnumerable<ReactorServiceEntity> GetManagedServices();

        /// <summary>
        /// Gets all <see cref="ServiceController"/> instances assigned to this Core.
        /// </summary>
        /// <returns></returns>
        IEnumerable<ServiceController> GetServiceControllers();

        /// <summary>
        /// Instructs the Core to adopt the specified service. This method creates 
        /// and invokes the workflow designated for service orphaning.
        /// </summary>
        /// <param name="serviceIdentifier">The service identifier.</param>
        void AdoptService(ServiceIdentifier serviceIdentifier);

        /// <summary>
        /// Instructs the Core to orphan the specified service. This method creates
        /// and starts the workflow designated for service orphaning.
        /// </summary>
        /// <param name="serviceIdentifier">The service identifier.</param>
        /// <param name="serviceInstanceIdentifier">The service instance identifier.</param>
        void OrphanService(ServiceIdentifier serviceIdentifier, Guid serviceInstanceIdentifier);

        /// <summary>
        /// Instructs the Core to restart the Windows Service hosting the specified 
        /// Reactor Service.
        /// </summary>
        /// <param name="serviceIdentifier">The service identifier.</param>
        void RestartService(ServiceIdentifier serviceIdentifier);

        /// <summary>
        /// Instructs the Core instance to shutdown the specified managed service.
        /// </summary>
        /// <param name="serviceIdentifier">The service identifier.</param>
        void ShutdownService(ServiceIdentifier serviceIdentifier);

        /// <summary>
        /// Instructs the Core instance to transfer a service from it's own control to
        /// another Core's control.
        /// </summary>
        /// <param name="transferCommand">The transfer command.</param>
        void TransferService(TransferService transferCommand);

        /// <summary>
        /// Resumes a previously started service transfer.
        /// </summary>
        /// <param name="adoptedEvent">The adopted event.</param>
        /// <param name="workflowId">The id of the workflow orchestrating the transfer process.</param>
        void ResumeServiceTransfer(ServiceAdopted adoptedEvent, Guid workflowId);

        /// <summary>
        /// Resumes a previously started service transfer workflow from the point where the recipient 
        /// Core receives the command to adopt the target service.
        /// </summary>
        /// <param name="adoptServiceCommand">The adopt service command.</param>
        /// <param name="workflowInstanceId">The id of the workflow orchestrating the transfer process.</param>
        void ResumeServiceTransfer(AdoptService adoptServiceCommand, Guid workflowInstanceId);
    }
}
