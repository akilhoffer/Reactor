﻿using System.Collections.Generic;
using System.Reflection;

namespace Reactor.ServiceGrid.ServiceInternals
{
    public interface IServiceCompositionContainer
    {
        /// <summary>
        /// Gets or sets the common parts registry.
        /// </summary>
        /// <value>The common parts registry.</value>
        IExtensionRegistry CommonPartsRegistry { get; set; }

        /// <summary>
        /// Gets or sets the extension parts registry.
        /// </summary>
        /// <value>The extension parts registry.</value>
        IExtensionRegistry ExtensionPartsRegistry { get; set; }

        /// <summary>
        /// Gets or sets the core parts registry.
        /// </summary>
        /// <value>The core parts registry.</value>
        IExtensionRegistry CorePartsRegistry { get; set; }

        /// <summary>
        /// Gets a list of assemblies that contain all composed service parts.
        /// </summary>
        /// <value>The service part assemblies.</value>
        IList<Assembly> ServicePartAssemblies { get; }

        /// <summary>
        /// Composes the extensions.
        /// </summary>
        void ComposeExtensions();
    }
}
