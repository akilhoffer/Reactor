﻿using System;

namespace Reactor.ServiceGrid.Utility {
    public interface IVersionSpec {
        Version MinVersion { get; }
        bool IsMinInclusive { get; }
        Version MaxVersion { get; }
        bool IsMaxInclusive { get; }
    }
}
