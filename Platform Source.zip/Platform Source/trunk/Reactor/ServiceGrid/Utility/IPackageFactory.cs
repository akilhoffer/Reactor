﻿using System;
using System.IO;
using Reactor.ServiceGrid.Packages;

namespace Reactor.ServiceGrid.Utility {
    public interface IPackageFactory {
        IPackage CreatePackage(Func<Stream> streamFactory);
    }
}
