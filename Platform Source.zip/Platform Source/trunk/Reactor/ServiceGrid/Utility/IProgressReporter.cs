﻿namespace Reactor.ServiceGrid.Utility {
    public interface IProgressReporter {
        void ReportProgress(string operation, int percentComplete);
    }
}
