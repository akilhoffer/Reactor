﻿using System;
using System.IO;
using Reactor.ServiceGrid.Packages;

namespace Reactor.ServiceGrid.Utility
{
    internal static class PackageUtility
    {
        internal static bool IsManifest(string path)
        {
            return Path.GetExtension(path).Equals(Constants.ManifestExtension, StringComparison.OrdinalIgnoreCase);
        }
    }
}
