﻿using System;
using Reactor.ServiceGrid.Packages;

namespace Reactor.ServiceGrid.Utility {
    public class ZipPackageFactory : IPackageFactory {
        public IPackage CreatePackage(Func<System.IO.Stream> streamFactory) {
            return new ZipPackage(streamFactory);
        }
    }
}
