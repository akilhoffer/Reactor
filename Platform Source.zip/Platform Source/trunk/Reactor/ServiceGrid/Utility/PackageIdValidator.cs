﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using Reactor.ServiceGrid.Resources;

namespace Reactor.ServiceGrid.Utility {
    public static class PackageIdValidator {
        private static readonly Regex IdRegex = new Regex(@"^\w+([_.-]\w+)*$", RegexOptions.IgnoreCase);

        public static bool IsValidPackageId(string packageId) {
            if (packageId == null)
                throw new ArgumentNullException("packageId");

            return IdRegex.IsMatch(packageId);
        }

        public static void ValidatePackageId(string packageId) {
            if (!IsValidPackageId(packageId))
                throw new ArgumentException(String.Format(CultureInfo.CurrentCulture,
                                                          ServiceGridResources.InvalidPackageId, packageId));
        }
    }
}
