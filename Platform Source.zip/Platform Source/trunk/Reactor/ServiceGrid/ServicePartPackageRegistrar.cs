﻿namespace Reactor.ServiceGrid
{
    public class ServicePartPackageRegistrar
    {
        public void RegisterServicePartPackage()
        {
            
        }

        
    }
}
