﻿using System;
using System.Activities;
using Reactor.Messages.Events.Adoptions;
using Reactor.Workflow.Activities;

namespace Reactor.ServiceGrid.Workflows.Activities
{
    public class ConstructOrphanedEvent : CreateMessageActivity<ServiceOrphaned>
    {
        public InArgument<ServiceIdentifier> ServiceIdentifier { get; set; }

        #region Overrides of CodeActivity<ServiceOrphaned>

        /// <summary>
        /// When implemented in a derived class, performs the execution of the activity.
        /// </summary>
        /// <returns>
        /// The result of the activity’s execution.
        /// </returns>
        /// <param name="context">The execution context under which the activity executes.</param>
        protected override ServiceOrphaned Execute(CodeActivityContext context)
        {
            var coreName = Environment.Context.GridContext.CurrentReactorService.Identifier.Name;
            var serviceIdentifier = context.GetValue(ServiceIdentifier);
            var msg = new ServiceOrphaned
            {
                ServiceName = serviceIdentifier.Name,
                Version = serviceIdentifier.Version.ToString(),
                CoreName = coreName,
                Subject = string.Format("Orphaned ReactorService: {0}", serviceIdentifier.Name),
                Description =
                    string.Format("The Reactor Core named '{0}' orphaned Reactor Service: '{1}' at: {2}", coreName, serviceIdentifier, DateTime.Now)
            };

            return msg;
        }

        #endregion
    }
}
