﻿using System.Activities;
using Reactor.Messages.Commands.Core;
using Reactor.Workflow.Activities;

namespace Reactor.ServiceGrid.Workflows.Activities
{
    public class ConstructAdoptServiceCommand : CreateMessageActivity<AdoptService>
    {
        [RequiredArgument]
        public InArgument<string> ServiceName { get; set; }

        [RequiredArgument]
        public InArgument<string> ServiceVersion { get; set; }

        [RequiredArgument]
        public InArgument<string> RecipientCoreName { get; set; }

        #region Overrides of CodeActivity<AdoptService>

        /// <summary>
        /// When implemented in a derived class, performs the execution of the activity.
        /// </summary>
        /// <returns>
        /// The result of the activity’s execution.
        /// </returns>
        /// <param name="context">The execution context under which the activity executes.</param>
        protected override AdoptService Execute(CodeActivityContext context)
        {
            var adoptionCommand = new AdoptService
            {
                CoreName = context.GetValue(RecipientCoreName),
                ServiceName = context.GetValue(ServiceName),
                ServiceVersion = context.GetValue(ServiceVersion)
            };

            return adoptionCommand;
        }

        #endregion
    }
}
