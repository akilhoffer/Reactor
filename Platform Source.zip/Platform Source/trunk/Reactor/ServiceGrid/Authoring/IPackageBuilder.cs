using System.Collections.ObjectModel;
using System.IO;
using Reactor.ServiceGrid.Packages;

namespace Reactor.ServiceGrid.Authoring
{
    public interface IPackageBuilder : IPackageMetadata
    {
        Collection<IPackageFile> Files { get; }
        void Save(Stream stream);
    }
}
