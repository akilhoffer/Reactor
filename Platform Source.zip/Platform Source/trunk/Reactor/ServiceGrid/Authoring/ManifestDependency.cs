﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using Reactor.ServiceGrid.Resources;

namespace Reactor.ServiceGrid.Authoring {
    [XmlType("dependency")]
    public class ManifestDependency {
        [Required(ErrorMessageResourceType = typeof(ServiceGridResources), ErrorMessageResourceName = "Manifest_DependencyIdRequired")]
        [XmlAttribute("id")]
        public string Id { get; set; }

        [XmlAttribute("version")]
        public string Version { get; set; }
    }
}