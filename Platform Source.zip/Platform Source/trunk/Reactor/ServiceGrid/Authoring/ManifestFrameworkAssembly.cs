﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using Reactor.ServiceGrid.Packages;
using Reactor.ServiceGrid.Resources;

namespace Reactor.ServiceGrid.Authoring
{
    [XmlType("frameworkAssembly", Namespace = Constants.ManifestSchemaNamespace)]
    public class ManifestFrameworkAssembly
    {
        [Required(ErrorMessageResourceType = typeof(ServiceGridResources), ErrorMessageResourceName = "Manifest_AssemblyNameRequired")]
        [XmlAttribute("assemblyName")]
        public string AssemblyName { get; set; }

        [XmlAttribute("targetFramework")]
        public string TargetFramework { get; set; }
    }
}
