﻿using System.Collections.Generic;
using System.Runtime.Versioning;

namespace Reactor.ServiceGrid
{
    public interface IFrameworkTargetable
    {
        IEnumerable<FrameworkName> SupportedFrameworks { get; }
    }
}
