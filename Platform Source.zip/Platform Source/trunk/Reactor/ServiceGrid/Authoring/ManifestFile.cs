﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using Reactor.ServiceGrid.Resources;

namespace Reactor.ServiceGrid.Authoring
{
    [XmlType("file")]
    public class ManifestFile
    {
        [Required(ErrorMessageResourceType = typeof(ServiceGridResources), ErrorMessageResourceName = "Manifest_RequiredMetadataMissing")]
        [XmlAttribute("src")]
        public string Source { get; set; }

        [XmlAttribute("target")]
        public string Target { get; set; }
    }
}