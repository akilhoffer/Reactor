using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using Reactor.Contracts;

namespace Reactor.ServiceGrid
{
    public interface IExtensionRegistry
    {
        /// <summary>
        /// Gets or sets the aggregate catalog.
        /// </summary>
        /// <value>The aggregate catalog.</value>
        AggregateCatalog AggregateCatalog { get; set; }

        /// <summary>
        /// Gets or sets the extensions.
        /// </summary>
        /// <value>The extensions.</value>
        [ImportMany]
        IEnumerable<IReactorExtension> Extensions { get; set; }

        /// <summary>
        /// Gets the default extension of the specified type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        T GetExtension<T>();
    }
}