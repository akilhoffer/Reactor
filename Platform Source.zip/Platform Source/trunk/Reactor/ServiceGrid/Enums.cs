﻿namespace Reactor.ServiceGrid
{
    public enum ServicePartCategory
    {
        CommonServicePart,
        CoreServicePart,
        ExtensionServicePart
    }
}
