﻿using System;
using Reactor.Environment;
using Reactor.Messages.Commands.Core;

namespace Reactor.ServiceGrid.Extensions
{
    public static class CommandExtensions
    {
        public static void IssueCommand(this AdoptService command, string serviceName, Version serviceVersion, string coreName, string startupArguments)
        {
            if (Context.ServiceBus == null) throw new InvalidOperationException("Cannot issue command if no IServiceBus instance can be located at Context.ServiceBus.");
            if (string.IsNullOrEmpty(serviceName)) throw new ArgumentNullException("serviceName");
            if (serviceVersion == null) throw new ArgumentNullException("serviceVersion");
            if (string.IsNullOrEmpty(coreName)) throw new ArgumentNullException("coreName");

            command.ServiceName = serviceName;
            command.ServiceVersion = serviceVersion.ToString();
            command.CoreName = coreName;
            command.StartupArguments = startupArguments;

            throw new NotImplementedException();
            //Context.ServiceBus.Send(command, new PointToPointChannel(coreName));
        }
    }
}
