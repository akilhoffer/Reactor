using System.Collections.Generic;
using Reactor.ServiceGrid.Packages;

namespace Reactor.ServiceGrid.PackageWalker
{
    public interface IDependentsResolver
    {
        IEnumerable<IPackage> GetDependents(IPackage package);
    }
}
