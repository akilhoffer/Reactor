namespace Reactor.ServiceGrid.PackageWalker
{
    public enum PackageAction
    {
        Install,
        Uninstall
    }
}
