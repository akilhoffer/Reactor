using System.Collections.Generic;
using Reactor.ServiceGrid.Packages;

namespace Reactor.ServiceGrid.PackageWalker
{
    public interface IPackageOperationResolver
    {
        IEnumerable<PackageOperation> ResolveOperations(IPackage package);
    }
}
