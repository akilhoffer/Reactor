using System;
using System.Runtime.Serialization;

namespace Reactor.ServiceGrid.Packages
{
    [DataContract]
    public class PackageSource : IEquatable<PackageSource>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageSource"/> class.
        /// </summary>
        /// <param name="source">The source.</param>
        public PackageSource(string source) : this(source, source) {}

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageSource"/> class.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="name">The name.</param>
        public PackageSource(string source, string name)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (name == null) throw new ArgumentNullException("name");

            Name = name;
            Source = source;
        }

        #endregion

        #region Properties

        [DataMember]
        public bool IsAggregate { get; set; }

        [DataMember]
        public string Name { get; private set; }

        [DataMember]
        public string Source { get; private set; }

        #endregion

        public static implicit operator PackageSource(string source)
        {
            return new PackageSource(source);
        }

        #region Equality Members

        public bool Equals(PackageSource other)
        {
            if (other == null)
            {
                return false;
            }

            return Name.Equals(other.Name, StringComparison.CurrentCultureIgnoreCase) &&
                   Source.Equals(other.Source, StringComparison.OrdinalIgnoreCase);
        }

        public override bool Equals(object obj)
        {
            var source = obj as PackageSource;
            if (obj != null)
            {
                return Equals(source);
            }
            return (obj == null) && base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode() ^ Source.GetHashCode();
        }

        #endregion

        public override string ToString()
        {
            return Name + " [" + Source + "]";
        }
    }
}
