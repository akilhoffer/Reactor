namespace Reactor.ServiceGrid.Packages {
    public static class Constants {
        public static readonly string PackageExtension = ".rspkg";
        public static readonly string ManifestExtension = ".rsspec";
        public static readonly string ContentDirectory = "content";

        internal const string PackageServiceEntitySetName = "Packages";

        internal const string ManifestSchemaNamespace = SchemaNamespace + "rsspec.xsd";
        internal const string SchemaNamespace = "http://schemas.microsoft.com/packaging/2010/07/";
    }
}
