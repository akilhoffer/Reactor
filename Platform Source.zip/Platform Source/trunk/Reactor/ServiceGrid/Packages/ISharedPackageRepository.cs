﻿using System;
using Reactor.ServiceGrid.Repositories;

namespace Reactor.ServiceGrid.Packages {
    public interface ISharedPackageRepository : IPackageRepository {
        bool IsReferenced(string packageId, Version version);

        /// <summary>
        /// Registers a new repository for the shared repository
        /// </summary>
        void RegisterRepository(string path);

        /// <summary>
        /// Removes a registered repository
        /// </summary>
        void UnregisterRepository(string path);
    }
}
