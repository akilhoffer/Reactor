﻿using System;

namespace Reactor.ServiceGrid.Packages
{
    public interface IServerPackageMetadata
    {
        Uri ReportAbuseUrl { get; }
        int DownloadCount { get; }
        int RatingsCount { get; }
        double Rating { get; }
    }
}
