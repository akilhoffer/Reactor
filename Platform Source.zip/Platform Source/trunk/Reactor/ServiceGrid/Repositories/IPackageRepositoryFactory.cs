using Reactor.ServiceGrid.Packages;

namespace Reactor.ServiceGrid.Repositories
{
    public interface IPackageRepositoryFactory
    {
        IPackageRepository CreateRepository(string source);
        IPackageRepository CreateRepository(PackageSource packageSource);
    }
}
