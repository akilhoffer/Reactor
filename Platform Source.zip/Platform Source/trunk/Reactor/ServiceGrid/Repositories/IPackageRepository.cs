using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Reactor.ServiceGrid.Packages;

namespace Reactor.ServiceGrid.Repositories
{
    public interface IPackageRepository
    {
        string Source { get; }

        [SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate", Justification = "This call might be expensive")]
        IQueryable<IPackage> GetPackages();

        void AddPackage(IPackage package);

        void RemovePackage(IPackage package);

        void Refresh();
    }
}
