using log4net;
using Reactor.ServiceGrid.Packages;
using System;
using System.Linq;

namespace Reactor.ServiceGrid.Repositories
{
    public abstract class PackageRepositoryBase : IPackageRepository
    {
        protected static ILog Log;
        public abstract string Source { get; }

        protected PackageRepositoryBase()
        {
            Log = LogManager.GetLogger(GetType());
        }

        public abstract IQueryable<IPackage> GetPackages();

        public virtual void AddPackage(IPackage package)
        {
            throw new NotImplementedException("The specific repository implementation being used does not contain an implementation for AddPackage.");
        }

        public virtual void RemovePackage(IPackage package)
        {
            throw new NotSupportedException();
        }

        public virtual void Refresh()
        {
            // Do nothing in default implementation. Derived classes can use this to perform 
            //  repository-specific refresh actions.
        }
    }
}
