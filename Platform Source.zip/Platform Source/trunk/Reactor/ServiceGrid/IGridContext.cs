﻿using System;
using Reactor.Providers;
using Reactor.ServiceGrid.Repositories;

namespace Reactor.ServiceGrid
{
    public interface IGridContext
    {
        /// <summary>
        /// Gets or sets the currently running service.
        /// </summary>
        /// <value>The current service.</value>
        IReactorService CurrentReactorService { get; set; }

        /// <summary>
        /// Gets or sets the service package repository containing all service packages 
        /// for the current execution environment.
        /// </summary>
        /// <value>The service package repository.</value>
        IPackageRepository ServicePackageRepository { get; set; }

        /// <summary>
        /// Gets or sets the data provider responsible for providing Reactor Core related data.
        /// </summary>
        /// <value>
        /// The core data provider.
        /// </value>
        ICoreDataProvider CoreDataProvider { get; set; }

        /// <summary>
        /// ServiceIdentifier being proposed as the service to create upon initialization.
        /// </summary>
        /// <value>
        /// The service identifier.
        /// </value>
        ServiceIdentifier ServiceIdentifier { get; set; }

        /// <summary>
        /// Service Instance Identifier being proposed for the service to be created upon initialization.
        /// </summary>
        /// <value>
        /// The service instance identifier.
        /// </value>
        Guid ServiceInstanceIdentifier { get; set; }
    }

    public class GridContext : IGridContext
    {
        #region Implementation of IGridContext

        /// <summary>
        /// Gets or sets the currently running service.
        /// </summary>
        /// <value>The current service.</value>
        public IReactorService CurrentReactorService { get; set; }

        /// <summary>
        /// Gets or sets the service package repository containing all service packages 
        /// for the current execution environment.
        /// </summary>
        /// <value>The service package repository.</value>
        public IPackageRepository ServicePackageRepository { get; set; }

        /// <summary>
        /// Gets or sets the data provider responsible for providing Reactor Core related data.
        /// </summary>
        /// <value>
        /// The core data provider.
        /// </value>
        public ICoreDataProvider CoreDataProvider { get; set; }

        /// <summary>
        /// ServiceIdentifier being proposed as the service to create upon initialization.
        /// </summary>
        /// <value>
        /// The service identifier.
        /// </value>
        public ServiceIdentifier ServiceIdentifier { get; set; }

        /// <summary>
        /// Service Instance Identifier being proposed for the service to be created upon initialization.
        /// </summary>
        /// <value>
        /// The service instance identifier.
        /// </value>
        public Guid ServiceInstanceIdentifier { get; set; }

        #endregion
    }
}
