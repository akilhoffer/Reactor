﻿using System;
using System.Runtime.Serialization;

namespace Reactor.Exceptions
{
    [Serializable]
    public class ContextValidationException : Exception
    {
        //
        // For guidelines regarding the creation of new exception types, see
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpgenref/html/cpconerrorraisinghandlingguidelines.asp
        // and
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dncscol/html/csharp07192001.asp
        //

        public ContextValidationException()
        {
        }

        public ContextValidationException(string message) : base(message)
        {
        }

        public ContextValidationException(string message, Exception inner) : base(message, inner)
        {
        }

        protected ContextValidationException(
            SerializationInfo info,
            StreamingContext context) : base(info, context)
        {
        }
    }
}
