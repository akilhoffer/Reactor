﻿using System;

namespace Reactor.Exceptions
{
    [Serializable]
    public class ConfigurationInitializationException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConfigurationInitializationException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        public ConfigurationInitializationException(string message) : base(message) {}
    }
}
