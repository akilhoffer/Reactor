﻿using System;
using System.Collections.Generic;
using System.Linq;
using MassTransit;
using Reactor.Providers;

namespace Reactor.Entities
{
    public class ReactorCoreEntity : ServiceEntityBase
    {
        #region Fields

        private readonly ICoreDataProvider _coreDataProvider;
        private readonly IServiceBus _serviceBus;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="ReactorCoreEntity"/> class.
        /// </summary>
        /// <param name="coreDataProvider">The core data provider.</param>
        public ReactorCoreEntity(ICoreDataProvider coreDataProvider, IServiceBus serviceBus)
        {
            if (coreDataProvider == null) throw new ArgumentNullException("coreDataProvider");
            if (serviceBus == null) throw new ArgumentNullException("serviceBus");

            _coreDataProvider = coreDataProvider;
            _serviceBus = serviceBus;
        }

        /// <summary>
        /// Gets a list of all services managed by this core.
        /// </summary>
        /// <value>The managed services.</value>
        public IEnumerable<ReactorServiceEntity> GetManagedServices()
        {
            var results = _coreDataProvider.GetAllServiceInstancesAssignedToCore(Identifier);
            return results.ToArray();
        }

        public void SendMessage<T>(T message)
        {
            throw new NotImplementedException();
        }
    }
}
