﻿using System;

namespace Reactor.Entities
{
    public class Subscription
    {
        public virtual Guid SubscriptionId { get; set; }
        public virtual string SubscriberName { get; set; }
        public virtual string SerializedSubscriber { get; set; }
    }
}
