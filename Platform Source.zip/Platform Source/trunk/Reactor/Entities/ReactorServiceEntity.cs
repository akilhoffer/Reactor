﻿using System;

namespace Reactor.Entities
{
    public class ReactorServiceEntity : ServiceEntityBase
    {
        public Guid InstanceIdentifier { get; set; }
    }
}
