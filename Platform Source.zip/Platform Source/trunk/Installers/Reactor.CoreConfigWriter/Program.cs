﻿using System;
using System.IO;
using log4net;
using Reactor.Configuration;

namespace Reactor.CoreConfigWriter
{
    class Program
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof (Program));

        static void Main(string[] args)
        {
            Log.Info("Starting CoreConfigWriter");

            var commandSet = Args.Configuration.Configure<CommandSet>().CreateAndBind(args);

            Log.DebugFormat("Configuration path: {0}", commandSet.ConfigFilePath);
            Log.DebugFormat("Database connection string: {0}", commandSet.DatabaseConnectionString);
            Log.DebugFormat("Broker connection string: {0}", commandSet.BrokerConnectionString);

            try
            {
                if(string.IsNullOrEmpty(commandSet.ConfigFilePath))
                    throw new Exception("No configuration file path supplied.");

                if(!File.Exists(commandSet.ConfigFilePath))
                    throw new FileNotFoundException(string.Format("Configuration file not found at: {0}", commandSet.ConfigFilePath));

                var writer = new ApplicationConfigurationWriter(commandSet.ConfigFilePath);
                writer.WriteConnectionString("ReactorServices", commandSet.DatabaseConnectionString);

                if(!string.IsNullOrEmpty(commandSet.BrokerConnectionString))
                {
                    Log.Debug("Broker connection string present. Attempting to write value to AppSettings section.");
                    writer.WriteSetting("BrokerConnectionString", commandSet.BrokerConnectionString);
                }

                Log.Info("Done.");
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception:");
                Console.WriteLine(e);

                Log.Fatal("Fatal Exception", e);
            }
        }
    }
}
