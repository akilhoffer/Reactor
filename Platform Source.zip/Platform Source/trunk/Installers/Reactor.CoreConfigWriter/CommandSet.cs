﻿namespace Reactor.CoreConfigWriter
{
    // arguments: /c [PATH] /d [DATABASE_CONNECTIONSTRING] /b [BROKER_CONNECTIONSTRING]
    internal class CommandSet
    {
        public string ConfigFilePath { get; set; }

        public string DatabaseConnectionString { get; set; }

        public string BrokerConnectionString { get; set; }
    }
}
