﻿using System.ComponentModel.Composition;
using Reactor.Configuration;
using Reactor.Environment;
using Reactor.Environment.Workflows;
using Reactor.Providers;

namespace Reactor.Connections.Default
{
    [Export(typeof(ICustomizeReactorInitialization))]
    public class ConnectionDataCustomizer : ICustomizeReactorInitialization
    {
        #region Implementation of ICustomizeReactorInitialization

        /// <summary>
        /// Gets the execution order for this initializer. The lower the value, the earlier it will 
        /// be executed in a chain of initializers.
        /// </summary>
        /// <value>The execution order.</value>
        public uint ExecutionOrder
        {
            get { return 1; }
        }

        /// <summary>
        /// Initializes Reactor by creating a <seealso cref="PlatformConnectionData"/> instance and bootstrapping it 
        /// with the <seealso cref="DefaultEnvironmentBootstrapper"/>.
        /// </summary>
        public void InitializeReactor()
        {
            // Need a connection data instance. Create default from config and register it with the service locator
            var platformConnectionData = new PlatformConnectionData
                                             {
                                                 InitilizationWorkflow = new DefaultEnvironmentBootstrapper()
                                             };
            platformConnectionData.Initialize();

            Context.ServiceLocator.RegisterInstance<PlatformConnectionData>(platformConnectionData);
            Context.GridContext.CoreDataProvider = Context.ServiceLocator.GetInstance<ICoreDataProvider>();
        }

        #endregion
    }
}
