﻿using Microsoft.Practices.Prism.Events;
using Reactor.Environment;
using Reactor.MiniManager.ViewModels;

namespace Reactor.MiniManager.Views
{
    /// <summary>
    /// Interaction logic for AdoptServiceDetailsDialog.xaml
    /// </summary>
    public partial class AdoptServiceDetailsDialog
    {
        public AdoptServiceDetailsDialog()
        {
            InitializeComponent();

            var eventAggregator = Context.ServiceLocator.GetInstance<IEventAggregator>();
            DataContext = new AdoptionDetailsViewModel(eventAggregator);
        }
    }
}
