﻿using Reactor.MiniManager.ViewModels;

namespace Reactor.MiniManager.Views
{
    /// <summary>
    /// Interaction logic for ServiceDetailsWindow.xaml
    /// </summary>
    public partial class CoreDetailsWindow
    {
        public CoreDetailsWindow()
        {
            InitializeComponent();

            Closing += CoreDetailsWindow_Closing;
        }

        internal void CoreDetailsWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            var vm = (CoreDetailsHostViewModel) DataContext;
            vm.Dispose();
        }
    }
}
