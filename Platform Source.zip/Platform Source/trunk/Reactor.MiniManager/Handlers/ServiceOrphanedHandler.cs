﻿using Reactor.Environment;
using Reactor.Messages.Events.Adoptions;
using Reactor.Messaging;
using Reactor.Messaging.Attributes;
using Reactor.MiniManager.Events;

namespace Reactor.MiniManager.Handlers
{
    [Topic]
    public class ServiceOrphanedHandler : ClientBasedMessageHandlerBase<ServiceOrphaned>
    {
        public override void OnHandling(ServiceOrphaned message, IMessageContext messageContext)
        {
            if(Log.IsDebugEnabled) Log.DebugFormat("ServiceOrphaned event received from bus. Destined for Core: {0} and targeted to Service: {1}", message.CoreName, message.ServiceName);

            EventAggregator.GetEvent<ServiceOrphanedEventReceived>().Publish(message);
        }
    }
}
