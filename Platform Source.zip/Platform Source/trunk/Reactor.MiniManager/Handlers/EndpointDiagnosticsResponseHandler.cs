﻿using Reactor.Messages.Replies.Diagnostics;
using Reactor.Messaging;
using Reactor.Messaging.Attributes;
using Reactor.MiniManager.Events;

namespace Reactor.MiniManager.Handlers
{
    [Queue] // We expect this response on our primary input queue.
    public class EndpointDiagnosticsResponseHandler : ClientBasedMessageHandlerBase<EndpointDiagnosticsResponse>
    {
        public override void OnHandling(EndpointDiagnosticsResponse message, IMessageContext messageContext)
        {
            EventAggregator.GetEvent<BusMessageReceived<EndpointDiagnosticsResponse>>().Publish(message);
        }
    }
}
