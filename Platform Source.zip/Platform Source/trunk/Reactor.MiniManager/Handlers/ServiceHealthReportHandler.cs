﻿using Reactor.Messages.Events.Failures;
using Reactor.Messaging;
using Reactor.MiniManager.Events;

namespace Reactor.MiniManager.Handlers
{
    public class ServiceNotRespondingHandler : ClientBasedMessageHandlerBase<ServiceNotResponding>
    {
        public override void OnHandling(ServiceNotResponding message, IMessageContext messageContext)
        {
            EventAggregator.GetEvent<BusMessageReceived<ServiceNotResponding>>().Publish(message);
        }
    }
}
