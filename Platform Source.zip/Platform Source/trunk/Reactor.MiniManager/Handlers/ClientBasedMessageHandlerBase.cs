﻿using log4net;
using Microsoft.Practices.Prism.Events;
using Reactor.Environment;
using Reactor.Messaging;

namespace Reactor.MiniManager.Handlers
{
    public abstract class ClientBasedMessageHandlerBase<T> : MessageHandlerBase<T> where T : class
    {
        protected IEventAggregator EventAggregator;

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientBasedMessageHandlerBase&lt;T&gt;"/> class.
        /// </summary>
        protected ClientBasedMessageHandlerBase()
        {
            Log = LogManager.GetLogger(GetType());
            EventAggregator = Context.ServiceLocator.GetInstance<IEventAggregator>();
        }
    }
}
