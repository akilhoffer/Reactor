﻿using System;
using Reactor.MiniManager.State;
using Reactor.MiniManager.Utility;

namespace Reactor.MiniManager.Extensions
{
    public static class ExtensionMethods
    {
        #region ICoreStateCache Extension Methods

        /// <summary>
        /// Executes the specified action on the UI thread. If this method is called from a non-WPF application,
        /// the action will be executed on the current thread and no exception will be thrown.
        /// </summary>
        /// <param name="stateCache">The state cache.</param>
        /// <param name="action">The action.</param>
        public static void ExecuteOnUiThread(this ICoreStateCache stateCache, Action action)
        {
            ThreadDispatches.ExecuteOnUiThread(action);
        }

        /// <summary>
        /// Executes the specified action on the UI thread. If this method is called from a non-WPF application,
        /// the action will be executed on the current thread and no exception will be thrown.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="stateCache">The state cache.</param>
        /// <param name="action">The action.</param>
        /// <param name="actionParameter">The action parameter.</param>
        public static void ExecuteOnUiThread<T>(this ICoreStateCache stateCache, Action<T> action, T actionParameter)
        {
            ThreadDispatches.ExecuteOnUiThread(action, actionParameter);
        }

        #endregion
    }
}
