﻿namespace Reactor.MiniManager
{
    public enum ServiceStatus
    {
        Unknown,
        Online,
        Offline
    }

    public enum CoreStatus
    {
        Unknown,
        AliveWithAllServices,
        AliveWithDownServices,
        OfflineWithAllServices,
        OfflineWithDownServices
    }
}
