﻿using Microsoft.Practices.Prism.Events;

namespace Reactor.MiniManager.Events
{
    public class BusMessageReceived<T> : CompositePresentationEvent<T>
    {
    }
}
