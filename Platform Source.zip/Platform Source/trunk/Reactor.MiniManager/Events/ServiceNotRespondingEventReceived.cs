﻿using Microsoft.Practices.Prism.Events;
using Reactor.Messages.Events.Failures;

namespace Reactor.MiniManager.Events
{
    public class ServiceNotRespondingEventReceived : CompositePresentationEvent<ServiceNotResponding>
    {
    }
}
