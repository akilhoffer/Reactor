﻿using Microsoft.Practices.Prism.Events;

namespace Reactor.MiniManager.Events
{
    public class CoreHealthCheckWorkflowFailed : CompositePresentationEvent<CoreHealthCheckWorkflowFailed>
    {
    }
}
