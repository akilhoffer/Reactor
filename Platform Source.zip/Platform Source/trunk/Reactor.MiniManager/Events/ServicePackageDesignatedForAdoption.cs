﻿using Microsoft.Practices.Prism.Events;
using Reactor.ServiceGrid.Packages;

namespace Reactor.MiniManager.Events
{
    public class ServicePackageDesignatedForAdoption : CompositePresentationEvent<ServicePackageDesignatedForAdoption>
    {
        public IPackage SelectedPackage { get; set; }

        public string StartupArguments { get; set; }
    }
}
