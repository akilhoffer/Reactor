﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Reactor.MiniManager.Controls
{
    public class ImageButton : Button
    {
        #region ImageSource Dependency Property

        /// <summary>
        /// Identifies the ImageSource dependency property.
        /// </summary>
        public static DependencyProperty ImageSourceProperty =
            DependencyProperty.Register("ImageSource", typeof(ImageSource), typeof(ImageButton), null);

        /// <summary>
        /// Image source for the image used as the template for this button.
        /// </summary>
        public ImageSource ImageSource
        {
            get { return (ImageSource)GetValue(ImageSourceProperty); }

            set { SetValue(ImageSourceProperty, value); }
        }

        #endregion
    }
}
