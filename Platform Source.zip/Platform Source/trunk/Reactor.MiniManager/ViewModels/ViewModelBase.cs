﻿using System;
using System.ComponentModel;
using Reactor.MiniManager.Utility;
using Samurai.Wakizashi;

namespace Reactor.MiniManager.ViewModels
{
    public class ViewModelBase : DisposableBase, INotifyPropertyChanged
    {
        #region Implementation of INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        protected void ExecuteOnUiThread(Action action)
        {
            ThreadDispatches.ExecuteOnUiThread(action);
        }

        protected void ExecuteOnUiThread<T>(Action<T> action, T parameter)
        {
            ThreadDispatches.ExecuteOnUiThread(action, parameter);
        }

        protected void OnPropertyChanged(string propertyName)
        {
            if(PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
