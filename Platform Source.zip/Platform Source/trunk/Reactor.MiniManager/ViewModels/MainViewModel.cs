﻿using System.Collections.ObjectModel;
using Reactor.Environment;
using Reactor.MiniManager.State;

namespace Reactor.MiniManager.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private string _statusText;
        private ReactorCoreViewModel _reactorCoreViewModel;

        /// <summary>
        /// Initializes a new instance of the <see cref="MainViewModel"/> class.
        /// </summary>
        public MainViewModel()
        {
            CoreStateCache = Context.ServiceLocator.GetInstance<ICoreStateCache>();
        }

        public ObservableCollection<ReactorCoreViewModel> Cores
        {
            get
            {
                return CoreStateCache.ReactorCoreViewModels;
            }
        }

        public string StatusText
        {
            get { return _statusText; }
            set
            {
                if (_statusText == value) return;

                _statusText = value;
                OnPropertyChanged("StatusText");
            }
        }

        public ReactorCoreViewModel ReactorCoreViewModel
        {
            get { return _reactorCoreViewModel; }
            set
            {
                if (_reactorCoreViewModel == value) return;

                _reactorCoreViewModel = value;
                OnPropertyChanged("ReactorCoreViewModel");
                StatusText = _reactorCoreViewModel.StatusText;
            }
        }

        public ICoreStateCache CoreStateCache { get; set; }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);

            Context.ServiceBus.Stop();
        }
    }
}
