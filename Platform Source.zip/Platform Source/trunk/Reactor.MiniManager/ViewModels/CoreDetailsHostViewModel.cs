﻿using System;
using Microsoft.Practices.Prism.Events;
using Reactor.Entities;
using Reactor.Environment;
using Reactor.Providers;

namespace Reactor.MiniManager.ViewModels
{
    public class CoreDetailsHostViewModel : ViewModelBase
    {
        #region Fields

        private readonly IEventAggregator _eventAggregator;
        private readonly ReactorCoreEntity _reactorCoreEntity;
        private BusDiagnosticsViewModel _diagnosticsViewModel;
        private CoreServicesViewModel _servicesViewModel;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="CoreDetailsHostViewModel"/> class.
        /// </summary>
        public CoreDetailsHostViewModel(IEventAggregator eventAggregator, ReactorCoreEntity reactorCoreEntity)
        {
            if (eventAggregator == null) throw new ArgumentNullException("eventAggregator");
            if (reactorCoreEntity == null) throw new ArgumentNullException("reactorCoreEntity");
            _eventAggregator = eventAggregator;
            _reactorCoreEntity = reactorCoreEntity;

            CreateDiagnosticsViewModelForThisCore();
            CreateServicesViewModelForThisCore();
        }

        public BusDiagnosticsViewModel DiagnosticsViewModel
        {
            get { return _diagnosticsViewModel; }
            set
            {
                if (_diagnosticsViewModel == value) return;

                _diagnosticsViewModel = value;
                OnPropertyChanged("DiagnosticsViewModel");
            }
        }

        public CoreServicesViewModel ServicesViewModel
        {
            get { return _servicesViewModel; }
            set
            {
                if (_servicesViewModel == value) return;

                _servicesViewModel = value;
                OnPropertyChanged("ServicesViewModel");
            }
        }

        private void CreateDiagnosticsViewModelForThisCore()
        {
            var vm = new BusDiagnosticsViewModel(_reactorCoreEntity, _eventAggregator);
            DiagnosticsViewModel = vm;
        }

        private void CreateServicesViewModelForThisCore()
        {
            var dataProvider = Context.ServiceLocator.GetInstance<ICoreDataProvider>();
            _servicesViewModel = new CoreServicesViewModel(_eventAggregator, dataProvider, _reactorCoreEntity);
        }
    }
}
