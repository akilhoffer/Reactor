﻿using System;
using System.Windows.Input;
using Microsoft.Practices.Prism.Commands;
using Reactor.Entities;
using Reactor.Environment;
using Reactor.Messages.Commands.Core;
using Reactor.Messaging;

namespace Reactor.MiniManager.ViewModels
{
    public class ServiceViewModel : ServiceViewModelBase<ReactorServiceEntity>
    {
        private readonly ReactorCoreEntity _reactorCoreEntity;

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceViewModel"/> class.
        /// </summary>
        /// <param name="serviceEntity">The service entity.</param>
        /// <param name="reactorCoreEntity"></param>
        public ServiceViewModel(ReactorServiceEntity serviceEntity, ReactorCoreEntity reactorCoreEntity) : base(serviceEntity)
        {
            if (reactorCoreEntity == null) throw new ArgumentNullException("reactorCoreEntity");
            
            _reactorCoreEntity = reactorCoreEntity;
            ShutdownServiceCommand = new DelegateCommand(ShutdownService);
            OrphanServiceCommand = new DelegateCommand(OrphanService);
            RestartServiceCommand = new DelegateCommand(RestartService);
        }

        /// <summary>
        /// Gets or sets the shutdown service command.
        /// </summary>
        /// <value>The shutdown service command.</value>
        public ICommand ShutdownServiceCommand { get; private set; }

        /// <summary>
        /// Gets or sets the orphan service command.
        /// </summary>
        /// <value>The orphan service command.</value>
        public ICommand OrphanServiceCommand { get; private set; }

        /// <summary>
        /// Gets or sets the restart service command.
        /// </summary>
        /// <value>The restart service command.</value>
        public ICommand RestartServiceCommand { get; private set; }

        private void ShutdownService()
        {
            var shutdownCommand = new ShutdownService
            {
                CoreName = _reactorCoreEntity.Identifier.Name,
                ServiceName = ServiceEntity.Identifier.Name,
                ServiceVersion = ServiceEntity.Identifier.Version.ToString()
            };
            Context.ServiceBus.Send(shutdownCommand, new Queue(_reactorCoreEntity.GetPrimaryInputQueue().DestinationName));
        }

        private void RestartService()
        {
            var restartCommand = new RestartService
                                     {
                                         CoreName = _reactorCoreEntity.Identifier.Name,
                                         ServiceName = ServiceEntity.Identifier.Name,
                                         ServiceVersion = ServiceEntity.Identifier.Version.ToString()
                                     };
            Context.ServiceBus.Send(restartCommand, new Queue(_reactorCoreEntity.Identifier.Name));
        }

        private void OrphanService()
        {
            var orphanCommand = new OrphanService
                                    {
                                        CoreName = _reactorCoreEntity.Identifier.Name,
                                        ServiceName = ServiceEntity.Identifier.Name,
                                        ServiceVersion = ServiceEntity.Identifier.Version.ToString()
                                    };
            Context.ServiceBus.Send(orphanCommand, new Queue(_reactorCoreEntity.Identifier.Name));
        }
    }
}
