﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Reactor.Environment;
using Reactor.MiniManager.Events;
using Reactor.ServiceGrid.Packages;

namespace Reactor.MiniManager.ViewModels
{
    public class AdoptionDetailsViewModel : ViewModelBase
    {
        #region Fields

        private readonly IEventAggregator _eventAggregator;
        private IPackage _selectedPackage;
        private bool? _dialogResult;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="AdoptionDetailsViewModel"/> class.
        /// </summary>
        public AdoptionDetailsViewModel(IEventAggregator eventAggregator)
        {
            if (eventAggregator == null) throw new ArgumentNullException("eventAggregator");

            _eventAggregator = eventAggregator;
            AssertThatRepositoryExists();

            LoadPackages();
            AcceptCommand = new DelegateCommand(Accept);
            CancelCommand = new DelegateCommand(Cancel);
        }

        /// <summary>
        /// Gets or sets the packages.
        /// </summary>
        /// <value>The packages.</value>
        public ObservableCollection<IPackage> Packages { get; set; }

        /// <summary>
        /// Gets or sets the selected package.
        /// </summary>
        /// <value>The selected package.</value>
        public IPackage SelectedPackage
        {
            get { return _selectedPackage; }
            set
            {
                if (_selectedPackage == value) return;

                _selectedPackage = value;
                OnPropertyChanged("SelectedPackage");
            }
        }

        /// <summary>
        /// Gets or sets the accept command.
        /// </summary>
        /// <value>The accept command.</value>
        public ICommand AcceptCommand { get; private set; }

        /// <summary>
        /// Gets or sets the cancel command.
        /// </summary>
        /// <value>The cancel command.</value>
        public ICommand CancelCommand { get; private set; }

        /// <summary>
        /// Gets or sets the dialog result.
        /// </summary>
        /// <value>The dialog result.</value>
        public bool? DialogResult
        {
            get { return _dialogResult; }
            set
            {
                if (_dialogResult == value) return;

                _dialogResult = value;
                OnPropertyChanged("DialogResult");
            }
        }

        private void Accept()
        {
            var designationEvent = new ServicePackageDesignatedForAdoption
                                       {
                                           SelectedPackage = SelectedPackage
                                       };
            _eventAggregator.GetEvent<ServicePackageDesignatedForAdoption>().Publish(designationEvent);
            DialogResult = true;
        }

        private void Cancel()
        {
            DialogResult = false;
        }

        private void LoadPackages()
        {
            var packages = (from p in Context.GridContext.ServicePackageRepository.GetPackages()
                            orderby p.Id
                            select p);
            Packages = new ObservableCollection<IPackage>(packages);
        }

        private static void AssertThatRepositoryExists()
        {
           if(Context.GridContext.ServicePackageRepository == null)
               throw new InvalidOperationException("No service package repository found on GridContext.");
        }
    }
}
