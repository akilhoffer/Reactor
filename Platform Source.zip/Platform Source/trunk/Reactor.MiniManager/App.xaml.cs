﻿using System.Windows;

namespace Reactor.MiniManager
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            var bootstrapper = new Bootstrapper();
            bootstrapper.Go();

            base.OnStartup(e);
        }
    }
}
