﻿using System;
using Reactor.Contracts;
using StructureMap;

namespace Reactor.Container.StructureMap
{
    public class StructureMapServiceRegistrar : IServiceRegistrar
    {
        private readonly IContainer _container;

        /// <summary>
        /// Initializes a new instance of the <see cref="StructureMapServiceRegistrar"/> class.
        /// </summary>
        public StructureMapServiceRegistrar(IContainer container)
        {
            if (container == null) throw new ArgumentNullException("container");

            _container = container;
        }

        #region Implementation of IServiceRegistrar

        /// <summary>
        /// Registers a single instance that is to be returned when the specified type is requested.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instance">The instance.</param>
        public void RegisterInstance<T>(object instance) where T : class
        {
            _container.Configure(c => c.For<T>().Add((T)instance));
        }

        /// <summary>
        /// Registers the a concrete type to associate with the abstract type.
        /// </summary>
        /// <typeparam name="T">Abstract type</typeparam>
        /// <typeparam name="TConcrete">The concrete type to instantiate when the abstract type is requested.</typeparam>
        public void RegisterType<T, TConcrete>() where TConcrete : T
        {
            _container.Configure(c => c.For<T>().Add<TConcrete>());
        }

        #endregion
    }
}
