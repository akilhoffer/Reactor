﻿using Castle.MicroKernel.Registration;
using Castle.Windsor;
using Reactor.Contracts;

namespace Reactor.Container.Windsor
{
    public class WindsorServiceRegistrar : IServiceRegistrar
    {
        private readonly IWindsorContainer _windsorContainer;

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="WindsorServiceRegistrar"/> class.
        /// </summary>
        /// <param name="windsorContainer">The windsor container.</param>
        public WindsorServiceRegistrar(IWindsorContainer windsorContainer)
        {
            _windsorContainer = windsorContainer;
        }

        #endregion

        #region Implementation of IServiceRegistrar

        /// <summary>
        /// Registers a single instance that is to be returned when the specified type is requested.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instance">The instance.</param>
        public void RegisterInstance<T>(object instance) where T : class
        {
            _windsorContainer.Register(Component.For<T>().Instance((T)instance).OverWrite());
        }

        /// <summary>
        /// Registers the a concrete type to associate with the abstract type.
        /// </summary>
        /// <typeparam name="T">Abstract type</typeparam>
        /// <typeparam name="TConcrete">The concrete type to instantiate when the abstract type is requested.</typeparam>
        public void RegisterType<T, TConcrete>() where TConcrete : T
        {
            _windsorContainer.Register(Component.For<T>().ImplementedBy<TConcrete>());
        }

        #endregion
    }
}
